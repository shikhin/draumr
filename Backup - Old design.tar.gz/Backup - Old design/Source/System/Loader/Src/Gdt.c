/* GDT function declarations.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Gdt.h>
#include <Types.h>
#include <String.h>

static gdt_gate_t gdt_gate[3] _aligned(16);

// Makes a gdt gate, based on the parameters given.
void gdt_set_gate(uint8_t gate_num, uint32_t base, uint32_t limit, uint8_t access, uint8_t granularity)
{
    gdt_gate[gate_num].limit = (limit & 0xFFFF);
    gdt_gate[gate_num].granularity = ((limit >> 16) & 0x0F);

    gdt_gate[gate_num].granularity = (uint8_t)((gdt_gate[gate_num].granularity) | (granularity & 0xF0));
    gdt_gate[gate_num].access = access;

    gdt_gate[gate_num].baseLow = (base & 0xFFFF);
    gdt_gate[gate_num].baseMiddle = (base >> 16) & 0xFF;
    gdt_gate[gate_num].baseHigh = (uint8_t)((base >> 24) & 0xFF);
}

// Initializes the GDT, makes three descriptors (NULL, Kernel Code, Kernel Data), and loads it.
void gdt_init()
{
    gdt_ptr_t gdt_ptr;

    gdt_ptr.size = (sizeof(gdt_gate_t) * 3) - 1;
    gdt_ptr.base = (uint32_t)&gdt_gate;

    memset(gdt_gate, 0, sizeof(gdt_gate_t) * 3);

    gdt_set_gate(0, 0, 0, 0, 0);
    gdt_set_gate(1, 0, 0xFFFFFFFF, 0x9A, 0xCF);
    gdt_set_gate(2, 0, 0xFFFFFFFF, 0x92, 0xCF);

    gdt_flush((uint32_t*)&gdt_ptr);
}

