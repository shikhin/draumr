/* NUMA definitions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <MP/Numa.h>
#include <MP/Acpi.h>
#include <Types.h>
#include <Macros.h>
#include <Kprintf.h>
#include <String.h>
#include <Cpu.h>

#include <Lib/Bitmap.h>

mem_range_t numa_bsp_mem_range()
{
    srat_t *srat = acpi_table_find("SRAT");
    slit_t *slit = acpi_table_find("SLIT");
    mem_range_t mem_range;
    uint32_t apic_id, numa_id = 0;

    memset(&mem_range, 0, sizeof(mem_range_t));

    if(!srat)
    {
	kprintf("Loader: SRAT not found.\n");
        kprintf("Loader: Assuming UMA architecture, with one domain.\n");

	return mem_range;
    }
    
    kprintf("Loader: SRAT found at: 0x%x.\n", (uint32_t)srat);
    apic_id = cpu_apic_id_get();
    kprintf("Loader: BSP has got a APIC ID of %d.\n", apic_id);

    for(uint8_t *type = (uint8_t*)&srat->type;
	(uint32_t)type < ((uint32_t)srat + srat->header.length);)
    {
        if(*type == 0)
	{
            srat_lapic_t *srat_lapic = (srat_lapic_t*)type;
	    if((srat_lapic->flags & 1) && (srat_lapic->apic_id == apic_id))
	    {
		numa_id = srat_lapic->numa_id_8;
		numa_id |= (srat_lapic->numa_id_16 << 8);
		numa_id |= (srat_lapic->numa_id_32) << 16;
	    	break;
	    }

	    else
		type += srat_lapic->length;
	}

	else if(*type == 1)
	{
	    srat_mem_t *srat_mem = (srat_mem_t*)type;
            type += srat_mem->length;
	}

	else if(*type == 2)
	{
	    srat_x2apic_t *srat_x2apic = (srat_x2apic_t*)type;
    	    type += srat_x2apic->length;
	}
    }

    kprintf("Loader: BSP in NUMA domain: %d.\n", numa_id);     
    
    mem_range = numa_find_mem_range(numa_id, srat);

    if(mem_range.length)
        return mem_range;
    
    uint32_t orig_numa_id = numa_id;
    
    if(slit)
        do
        {
        
        } while(!mem_range.length && (numa_id != orig_numa_id));
    
    return mem_range; 
}

mem_range_t numa_find_mem_range(uint32_t numa_id, srat_t *srat)
{
    mem_range_t mem_range;
    memset(&mem_range, 0, sizeof(mem_range));
    mem_range.numa_id = numa_id;

    for(uint8_t *type = (uint8_t*)&srat->type;
	(uint32_t)type < ((uint32_t)srat + srat->header.length);)
    {
        if(*type == 0)
	{
	    srat_lapic_t *srat_lapic = (srat_lapic_t*)type;    
	    type += srat_lapic->length;
	}

	else if(*type == 1)
	{
            srat_mem_t *srat_mem = (srat_mem_t*)type;

            if((srat_mem->flags & 1) && (srat_mem->numa_id == numa_id))
	    {
		if(srat_mem->region_length > mem_range.length)
		{
	            mem_range.length = srat_mem->region_length;
	 	    mem_range.base_addr = srat_mem->base_addr;	    
		}
	    }

	    type += srat_mem->length;
	}

	else if(*type == 2)
	{
	    srat_x2apic_t *srat_x2apic = (srat_x2apic_t*)type;
	    type += srat_x2apic->length;
	}
    }

    return mem_range;
}
