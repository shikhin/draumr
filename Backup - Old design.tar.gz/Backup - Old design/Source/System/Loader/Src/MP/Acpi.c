/* ACPI definitions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <MP/Acpi.h>
#include <Types.h>
#include <String.h>

static rsdp_t *rsdp = NULL;
static rsdp2_t *rsdp2 = NULL;

// Initializes ACPI usage.
void acpi_table_init(uint32_t acpi)
{
    // Decide whether to use RSDT or XSDT. 
    // If rsdp2 contains a non-zero value, use the XSDT.
    xsdt_t *xsdt = NULL;
    char checksum = 0;
    uint32_t i;

    if(!acpi)
        return;

    rsdp = (rsdp_t*)acpi;
    if(rsdp->revision > 0)
    {
        rsdp2 = (rsdp2_t*)rsdp;
        for(i = 0; i < (sizeof(rsdp2_t) - sizeof(rsdp_t)); i++)
            checksum += ((char*)(&rsdp2->length))[i];

        if(checksum)
        {
            rsdp2 = NULL;
            return;
        }

        if(rsdp2->xsdt_address & 0xFFFFFFFF00000000)
        {
            rsdp2 = NULL; 
            return;
        }
  
        xsdt = (xsdt_t*)(uint32_t)rsdp2->xsdt_address;
        checksum = 0;
        for(i = 0; i < xsdt->header.length; i++)
            checksum += ((char*)(xsdt))[i];

        if(checksum)
        {
            rsdp2 = NULL;
            return;
        }

        for(uint64_t k = 0; k < ((xsdt->header.length - sizeof(sdt_header_t)) / 8); k++)
        {
            uint64_t header_addr = *((uint64_t*)&xsdt->first_sdt + k);
            if(header_addr & 0xFFFFFFFF00000000)
            {
                 rsdp2 = NULL;
                 return;
            }	  
        }
    }    
}

// Finds a ACPI table with signature 'signature'
void *acpi_table_find(char *signature)
{
    if(!rsdp2 && rsdp)
    {
        rsdt_t *rsdt = (rsdt_t*)(rsdp->rsdt_address);
	for(uint32_t k = 0; k < ((rsdt->header.length - sizeof(sdt_header_t)) / 4); k++)
        {
            void *header = (sdt_header_t*)*((uint32_t*)&rsdt->first_sdt + k);
	    if(memcmp(header, signature, 4))
		return header;
        } 
    }
  
    else if(rsdp)
    {
	xsdt_t *xsdt = (xsdt_t*)(uint32_t)(rsdp2->xsdt_address);
	for(uint64_t k = 0; k < ((xsdt->header.length - sizeof(sdt_header_t)) / 8); k++)
        {
            void *header = (sdt_header_t*)(uint32_t)*((uint64_t*)&xsdt->first_sdt + k);
	    if(memcmp(header, signature, 4))
		return header;
        } 
    }

    return 0;
}
