/* C entry point of the intermediate loader.
*
* Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along
* with this program; if not, write to the Free Software Foundation, Inc.,
* 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <Types.h>
#include <Multiboot.h>
#include <Kprintf.h>
#include <Cpu.h>
#include <Gdt.h>
#include <Elf.h>
#include <MM/Pmm.h>
#include <MM/Vmm.h>
#include <Header/Header.h>
#include <MP/Acpi.h>
#include <String.h>
#include <Real/Real.h>

#include <Lib/Screen.h>

extern uint32_t real16, real16_end;

void loader_main(uint32_t magic, mb_info_t* mb_info)
{
    uint32_t cpu_features;
    uint64_t mem_total;
    mb_mod_t mod;
    draumr_hdr_t draumr_hdr;
    tables_if_t *tables_if;

    memcpy((void*)0x7c00, (void*)&real16, (uint32_t)&real16_end - (uint32_t)&real16);
    real_do_job(Get_Information);
    uint32_t *mmap_tech = (uint32_t*)0x9000;

    /* Initialize screen. */
    screen_init(0xb8000, 1);
    /* Validate the multiboot magic number. */

    kprintf("Memory map found by: %x.\n", *mmap_tech);

    if (magic != MB_LOADER_MAGIC)
        PANIC("Invalid multiboot magic number.");

    /* Initialize the GDT */
    gdt_init();

    kprintf("Draumr loading ...\n");
    
    /* Detect available CPU features. */
    if (!cpu_features_detect())
        PANIC("Could not detect CPU features.");

    /* Initialize the second stage of Draumr Header */
    tables_if = draumr_hdr_init(HDR_PHYS, &draumr_hdr, mb_info);

    /* Initialize ACPI (RSDP, RSDP2, etc) for further usage */
    acpi_table_init(tables_if->acpi_addr);

    /* Initialize the PMM */
    mem_total = pmm_init(mb_info); 
    kprintf("Loader: Total memory: %u MiB.\n", (uint32_t)(mem_total / 1024 / 1024));

    /* Set the video memory portion as 'used' */
    pmm_frame_set(0xb8000);

    /* Get the CPU features */
    cpu_features = cpu_features_get();

    /* Find the system kernel module. */
    if(cpu_features & Long)
        module_find(mb_info, "/System/KernelLong", "KernelLong", &mod);

    else
        module_find(mb_info, "/System/Kernel", "Kernel", &mod);

    kprintf("Loader: Found kernel module at: 0x%p.\n", mod.start_addr);
    pmm_frame_range_set(mod.start_addr, mod.end_addr);

    /* The algorithm used to determine which VMM to run is designed such that we waste
     * no extra RAM, and use all possible features:

     * If Long Mode is supported, without any hesitation we run the Long Mode VMM. 

     * If PAE is supported, and EITHER the NX bit is available OR the total amount
     * of usable physical memory (encompasses both 'used' and 'free') is greater
     * than 0xFFFFFFFF, OR the ACPI version is greater than 0, we run the PAE VMM.
     * If we run PAE by default (whenever supported), we may be wasting double the RAM
     * without getting any good features. 
     
     * If neither of the above to are supported, we run the Legacy VMM (as if we had some
     * choice, huh? ;-) */

    if (cpu_features & Long)
    {
        kprintf("Loader: Using Long Mode VMM.\n");
        vmm_init(KERNEL_LONG);
    }

    else if ((cpu_features & PAE) &&
        ((cpu_features & NX) || (mem_total > 0xffffffff) || (tables_if->acpi_ver > 0)))
    {
        kprintf("Loader: Using PAE VMM.\n");
        vmm_init(KERNEL_PAE);
        tables_if->boot_flags |= PAE_FLAG;
    }

    else
    {
        kprintf("Loader: Using legacy VMM.\n");
        vmm_init(KERNEL_LEGACY);
    }
    
    /* Initialize the second stage of Draumr Header */
    draumr_hdr_init(HDR_VIRT, &draumr_hdr, NULL);

    if (cpu_features & Long)
        elf_load_64((void*)mod.start_addr, 0xBADC0FEE, tables_if->boot_flags, 0);

    elf_load((void*)mod.start_addr, 0xBADC0FEE, tables_if->boot_flags, 0);
}
