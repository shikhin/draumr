/* Multiboot functions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Multiboot.h>
#include <Types.h>
#include <Kprintf.h>
#include <String.h>

// Finds a module in the modules loaded by GRUB
void module_find(mb_info_t* mb_info, const char* sig, const char* sig_alt, mb_mod_t* mb_mod)
{
    mb_mod_t* mod_list = (mb_mod_t*)mb_info->mod_addr;

    if (mb_info->mod_count < 1)
        PANIC("Module not found");

    for (uint32_t i = 0; i < mb_info->mod_count; i++)
    {
        mb_mod_t* tmp = &mod_list[i];

        if (!strcmp(sig, (char*)tmp->string) || !strcmp(sig_alt, (char*)tmp->string))
        {
            memcpy(mb_mod, tmp, sizeof(mb_mod_t));
            return;
        }
    }

    PANIC("Module not found");
}
