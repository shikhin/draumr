/* Draumr Header definitions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Header/Header.h>
#include <Types.h>
#include <Macros.h>
#include <Header/Acpi.h>
#include <Header/Mps.h>
#include <Header/Smbios.h>
#include <Header/Tables.h>
#include <MM/Vmm.h>
#include <String.h>
#include <Multiboot.h>
#include <Cpu.h>

static tables_if_t tables_if;

// Initializes the Draumr Header.
tables_if_t* draumr_hdr_init(uint32_t init_stage, draumr_hdr_t *draumr_hdr, mb_info_t* mb_info)
{
    static uint32_t acpi = 0, mps = 0, smbios = 0;
    
    if(init_stage == HDR_PHYS)
    {
        table_find(&acpi, &mps, &smbios, mb_info);
        if(acpi)
	{
            rsdp_t *rsdp = (rsdp_t*)acpi;
	    tables_if.acpi_ver = rsdp->revision;
	    tables_if.boot_flags |= ACPI_FLAG;
	}
        
	if(mps)
	    tables_if.boot_flags |= MPS_FLAG;

        if(smbios)
            tables_if.boot_flags |= SMBIOS_FLAG;

	tables_if.acpi_addr = acpi;
        return &tables_if;
    }

    else if(init_stage == HDR_VIRT)
    {
        uint64_t RELOCATE_ADDR;
        if(cpu_features_get() & Long)
	    RELOCATE_ADDR = RELOCATE_ADDR_64;
 
        else
            RELOCATE_ADDR = RELOCATE_ADDR_32;

        uint32_t offset = sizeof(draumr_hdr_t); 
        vmm_alloc_frame(RELOCATE_ADDR, PAGE_WRITE);

        memcpy((void*)draumr_hdr, "DRAUMR  ", 8);

	acpi_table_relocate(acpi, draumr_hdr, &offset);
        mps_table_relocate(mps, draumr_hdr, &offset);
   	smbios_table_relocate(smbios, draumr_hdr, &offset);

        memcpy_to_virtual(RELOCATE_ADDR, (ptr_t)draumr_hdr, sizeof(draumr_hdr_t));
    }

    return &tables_if;
}
