/* Common (acpi, mps and smbios) table definitions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Header/Tables.h>
#include <Header/Header.h>
#include <Types.h>
#include <Header/Acpi.h>
#include <Header/Mps.h>
#include <Header/Smbios.h>
#include <String.h>
#include <MM/Pmm.h>
#include <Multiboot.h>
#include <Kprintf.h>

// Find the tables and returns their address.
void table_find(uint32_t *acpi, uint32_t *mps, uint32_t *smbios, mb_info_t* mb_info)
{
    uint16_t *ebda_address = (uint16_t*)BDA_EBDA_ADDR;
    ebda_address = (uint16_t*)(*ebda_address << 4);
    if(!ebda_address)
        ebda_address = (uint16_t*)DEFAULT_EBDA_ADDR;
    
    uint8_t *ebda = (uint8_t*)ebda_address;
    uint8_t *bios = (uint8_t*)BIOS_READ_ONLY_MEM;

    uint8_t checksum;
    uint32_t i;

    /* Look for the RSDP and the MPFS table in the first Kibibyte of
     * the Extended BIOS Data Area */
    while((uint32_t)ebda < ((uint32_t)ebda_address + KIBIBYTE))
    {
        if(!*acpi && memcmp(ebda, "RSD PTR ", 8))
        {	
	    checksum = 0;
	    uint8_t *table = (uint8_t*)ebda;
	    for(i = 0; i < sizeof(rsdp_t); i++)
	    {
	        checksum += table[i];
	    }
	  
            if(!checksum)
	    {
	        *acpi = (uint32_t)ebda;
                kprintf("Loader: Found RSDP at: 0x%p.\n", *acpi);
                if(*mps)
                    break;
	    }
        }
      
        else if(!*mps && memcmp(ebda, "_MP_", 4))
	{
	    checksum = 0;
	    uint8_t *table = (uint8_t*)ebda;
	    for(i = 0; i < sizeof(mpfs_t); i++)
	    {
	        checksum += table[i]; 
	    }

            if(!checksum)
	    {
	        *mps = (uint32_t)ebda;
		kprintf("Loader: Found MPFS at: 0x%p.\n", *mps);
		if(*acpi)
		    break;
	    }
        }

        ebda += 16;
    }

    /* Look for the MPS table in the last Kilobyte of base memory. */
    if(!*mps && (mb_info->flags & 1))
    {
        uint8_t *last_kb_base_mem = (uint8_t*)((mb_info->mem_lower * KIBIBYTE) - KIBIBYTE);
        while((uint32_t)last_kb_base_mem < (mb_info->mem_lower * KIBIBYTE))
        {
            if(memcmp(last_kb_base_mem, "_MP_", 4))
	    {
	        checksum = 0;
	        uint8_t *table = (uint8_t*)last_kb_base_mem;
	        for(i = 0; i < sizeof(mpfs_t); i++)
	        {
	            checksum += table[i]; 
	        }

                if(!checksum)
	        {
	            *mps = (uint32_t)last_kb_base_mem;
		    kprintf("Loader: Found MPFS at: 0x%p.\n", *mps);
                    break;
	        }
            }

	    last_kb_base_mem += 16;
        }
    }

    /* Look for the RSDP in the BIOS read only area */
    if(!*acpi)
    {
        while((uint32_t)bios < 0xEFFFF)
        {
 	    if(memcmp(bios, "RSD PTR ", 8))
	    {
	        checksum = 0;
	        uint8_t *table = (uint8_t*)bios;
	        for(i = 0; i < sizeof(rsdp_t); i++)
	        {
	            checksum += table[i];
	        }

	        if(!checksum)
	        {
	            *acpi = (uint32_t)bios;
		    kprintf("Loader: Found RSDP at: 0x%p.\n", *acpi);
	            break;
	        }
            }

            bios += 16;
        }
    }

    /* Look for RSDP, MPFS and SMBIOS Entry Point Structure from
     * 0xF0000 -> 0xFFFFF (BIOS read only area) */
    bios = (uint8_t*)0xF0000;
    while((uint32_t)bios < 0x000FFFFF)
    {
	if(!*acpi && memcmp(bios, "RSD PTR ", 8))
	{
	    checksum = 0;
	    uint8_t *table = (uint8_t*)bios;
	    for(i = 0; i < sizeof(rsdp_t); i++)
	    {
	       checksum += table[i];
	    }

	    if(!checksum)
	    {
	        *acpi = (uint32_t)bios;
	        kprintf("Loader: Found RSDP at: 0x%p.\n", *acpi);
                if(*mps && *smbios)
		    break;
	    }
        }

	if(!*mps && memcmp(bios, "_MP_", 4))
        {
	    checksum = 0;
	    uint8_t *table = (uint8_t*)bios;
	    for(i = 0; i < sizeof(mpfs_t); i++)
	    {
	       checksum += table[i]; 
	    }
	    if(!checksum)
	    {
	        *mps = (uint32_t)bios;
		kprintf("Loader: Found MPFS at: 0x%p.\n", *mps);
	        if(*acpi && *smbios)
	            break;
	    }
        }

	if(!*smbios && memcmp(bios, "_SM_", 4))
        {
	    checksum = 0;
	    uint8_t *table = (uint8_t*)bios;
	    for(i = 0; i < bios[5]; i++)
	    {
	       checksum += table[i]; 
	    }

	    if(!checksum)
	    {
	        *smbios = (uint32_t)bios;
		kprintf("Loader: Found SMBIOS Entry Point Table at: 0x%p.\n", *smbios);
	        if(*acpi && *mps)
	            break;
	    }
        }

        bios += 16;
    }
}
