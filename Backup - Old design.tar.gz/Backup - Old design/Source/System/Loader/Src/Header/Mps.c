/* MPS relocation (Draumr Header) functions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Header/Header.h>
#include <Header/Mps.h>
#include <Types.h>
#include <Macros.h>
#include <MM/Vmm.h>
#include <MM/Pmm.h>
#include <String.h>
#include <Kprintf.h>
#include <Cpu.h>

/* Relocates the MPS tables, and fills in the neccessary information in the Draumr Header */
void mps_table_relocate(uint32_t mps, draumr_hdr_t *draumr_hdr, uint32_t *offset)
{
    mpfs_t *mpfs = NULL;
    mpct_t *mpct = NULL;
    uint32_t i, length, vers;

    if(!mps)
	return;
    
    uint64_t RELOCATE_ADDR;
    if(cpu_features_get() & Long)
	RELOCATE_ADDR = RELOCATE_ADDR_64;
 
    else
        RELOCATE_ADDR = RELOCATE_ADDR_32;

    length = mps_table_length(mps, &vers);
    for(i = (*offset & PAGE_MASK) + PAGE_SIZE; i < (*offset + length); i += PAGE_SIZE)
	vmm_alloc_frame(i, PAGE_WRITE);

    mpfs = (mpfs_t*)mps;
    draumr_hdr->mp_floating_point = (uint32_t)(RELOCATE_ADDR + *offset);
    *offset += sizeof(mpfs_t);

    /* If feature_info is non-zero, you have to use the "default cases" described
     * in the MP Specification */
    if(!vers)
    {
	memcpy_to_virtual(draumr_hdr->mp_floating_point, (uint32_t)mpfs, sizeof(mpfs_t));
	return;
    }

    mpct = (mpct_t*)mpfs->mpct_address;
    memcpy_to_virtual(RELOCATE_ADDR + *offset, (uint32_t)mpct, mpct->base_length + mpct->extended_length);

    mpfs->mpct_address = RELOCATE_ADDR + *offset;
    memcpy_to_virtual(draumr_hdr->mp_floating_point, (uint32_t)mpfs, sizeof(mpfs_t));

    *offset += mpct->base_length + mpct->extended_length;
}

/* Returns the total length of the MPS tables, which is used by 'mps_table_relocate' to create neccessary tables */
size_t mps_table_length(uint32_t mps, uint32_t *vers)
{
    mpfs_t *mpfs = NULL;
    mpct_t *mpct = NULL;
    uint32_t length = 0;
    *vers = 1;

    if(!mps)
	return length;

    length += sizeof(mpfs_t);
    mpfs = (mpfs_t*)mps;

    /* If feature_info is non-zero, you have to use the "default cases" described
     * in the MP Specification */
    if(mpfs->feature_info)
    {
        kprintf("Loader: MPS root table feature byte non zero. Using one of the default cases.\n");
        *vers = 0;
	return length;
    }

    mpct = (mpct_t*)mpfs->mpct_address;
    length += mpct->base_length + mpct->extended_length;

    return length;
}
