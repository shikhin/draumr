/* ACPI relocation (Draumr header) definitions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Macros.h>
#include <Types.h>
#include <Header/Acpi.h>
#include <Header/Header.h>
#include <String.h>
#include <Kprintf.h>
#include <MM/Vmm.h>
#include <MM/Pmm.h>
#include <Cpu.h>

/* Relocates the acpi tables, and fills in the neccessary information in the Draumr header */
void acpi_table_relocate(uint32_t acpi, draumr_hdr_t *draumr_hdr, uint32_t *offset)
{
    uint32_t i, vers, length;
    rsdp_t *rsdp = NULL; rsdp2_t *rsdp2 = NULL;
    rsdt_t *rsdt = NULL; xsdt_t *xsdt = NULL;
    uint64_t RELOCATE_ADDR;
    if(cpu_features_get() & Long)
	RELOCATE_ADDR = RELOCATE_ADDR_64;
 
    else
        RELOCATE_ADDR = RELOCATE_ADDR_32;

    if(!acpi)
        return;

    length = acpi_table_length(acpi, &vers);
    for(i = PAGE_SIZE; i < length; i += PAGE_SIZE)
	vmm_alloc_frame(RELOCATE_ADDR + i, PAGE_WRITE);

    memcpy_to_virtual(RELOCATE_ADDR + *offset, acpi, sizeof(rsdp2_t));    
    draumr_hdr->rsdp = (uint32_t)(RELOCATE_ADDR + *offset);

    rsdp = (rsdp_t*)acpi;
    *offset += sizeof(rsdp2_t);

    if(!vers)
    {
        rsdt = (rsdt_t*)rsdp->rsdt_address;
        memcpy_to_virtual(RELOCATE_ADDR + *offset, (uint32_t)rsdt, rsdt->header.length);

        rsdp->rsdt_address = RELOCATE_ADDR + *offset;
        *offset += rsdt->header.length;

        /* Relocate all the other tables */
        for(i = 0; i < ((rsdt->header.length - sizeof(sdt_header_t)) / 4); i++)
        {
            sdt_header_t *header = (sdt_header_t*)*((uint32_t*)&rsdt->first_sdt + i);
            *((uint32_t*)&rsdt->first_sdt + i) = RELOCATE_ADDR + *offset;
            
	    memcpy_to_virtual(RELOCATE_ADDR + *offset, (uint32_t)header, header->length); 
	    
	    *offset += header->length;
        }        
    }

    else
    {
        xsdt = (xsdt_t*)(uint32_t)rsdp2->xsdt_address;
        memcpy_to_virtual(RELOCATE_ADDR + *offset, (uint32_t)xsdt, xsdt->header.length);

        rsdp2->xsdt_address = (uint64_t)RELOCATE_ADDR + *offset;
        *offset += xsdt->header.length;

        for(uint64_t k = 0; k < ((xsdt->header.length - sizeof(sdt_header_t)) / 8); k++)
        {
            sdt_header_t *header = (sdt_header_t*)*(uint32_t*)((uint64_t*)&xsdt->first_sdt + k);
            *((uint64_t*)&xsdt->first_sdt + k) = RELOCATE_ADDR + *offset;
	  
	    memcpy_to_virtual(RELOCATE_ADDR + *offset, (uint32_t)header, header->length); 

            *offset += header->length;
        }        
    }
}


/* Returns the total length of the ACPI tables, which is used by 'acpi_table_relocate' to create neccessary tables. */
size_t acpi_table_length(uint32_t acpi, uint32_t *vers)
{
    size_t rsdt_length, xsdt_length, i;
    *vers = 1;
    
    rsdp_t *rsdp = NULL; rsdp2_t *rsdp2 = NULL;
    rsdt_t *rsdt = NULL; xsdt_t *xsdt = NULL;
 
    if(!acpi)
        return 0;
  
    rsdp = (rsdp_t*)acpi;
    rsdt_length = xsdt_length = sizeof(rsdp2_t);
    if(rsdp->revision > 0)
        rsdp2 = (rsdp2_t*)rsdp;

    rsdt = (rsdt_t*)rsdp->rsdt_address;
    rsdt_length += rsdt->header.length;
    char checksum = 0;
    
    for(i = 0; i < ((rsdt->header.length - sizeof(sdt_header_t)) / 4); i++)
    {
        sdt_header_t *header = (sdt_header_t*)*((uint32_t*)&rsdt->first_sdt + i);
        rsdt_length += header->length;
    } 

    if(!rsdp2)
    {
        kprintf("Loader: ACPI version %d. XSDT not supported. Defaulting to RSDT instead.\n", (uint32_t)rsdp->revision);
        *vers = 0;
   
	return rsdt_length;
    }

    for(i = 0; i < (sizeof(rsdp2_t) - sizeof(rsdp_t)); i++)
        checksum += ((char*)(&rsdp2->length))[i];
    
    if(checksum)
    {
        kprintf("Loader: RSDP2 has failed checksum. Defaulting to RSDT instead.\n");
        *vers = 0;
        return rsdt_length;    
    }
    
    if(rsdp2->xsdt_address & 0xFFFFFFFF00000000)
    {
        kprintf("Loader: XSDT uses 64-bit pointers. Defaulting to RSDT instead.\n");
        *vers = 0;
        return rsdt_length;
    }

    xsdt = (xsdt_t*)(uint32_t)rsdp2->xsdt_address;
    checksum = 0;
    for(i = 0; i < xsdt->header.length; i++)
        checksum += ((char*)(xsdt))[i];

    if(checksum)
    {
        kprintf("Loader: XSDT has failed checksum. Defaulting to RSDT instead.\n");
        *vers = 0;
        return rsdt_length;
    }

    xsdt_length += xsdt->header.length;

    for(uint64_t k = 0; k < ((xsdt->header.length - sizeof(sdt_header_t)) / 8); k++)
    {
        uint64_t header_addr = *((uint64_t*)&xsdt->first_sdt + k);
        if(header_addr & 0xFFFFFFFF00000000)
        {
            kprintf("Loader: XSDT uses 64-bit pointers. Defaulting to RSDT instead.\n");
            *vers = 0;
            break;
        }	  
   
        sdt_header_t *header = (sdt_header_t*)(uint32_t)header_addr;
        xsdt_length += header->length;
    }    
 
    if(*vers)
	return xsdt_length;

    return rsdt_length;
}
