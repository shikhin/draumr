/* SMBIOS relocation (Draumr Header) functions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Header/Header.h>
#include <Header/Smbios.h>
#include <Types.h>
#include <Macros.h>
#include <MM/Vmm.h>
#include <MM/Pmm.h>
#include <String.h>
#include <Cpu.h>

/* Relocates the SMBIOS tables, and fills in the neccessary information in the Draumr Header */
void smbios_table_relocate(uint32_t smbios, draumr_hdr_t *draumr_hdr, uint32_t *offset)
{
    smbios_eps_t *smbios_eps = (smbios_eps_t*)smbios;
    uint32_t length;

    if(!smbios)
	return;
    
    uint64_t RELOCATE_ADDR;
    if(cpu_features_get() & Long)
	RELOCATE_ADDR = RELOCATE_ADDR_64;
 
    else
        RELOCATE_ADDR = RELOCATE_ADDR_32;

    length = smbios_table_length(smbios);

    draumr_hdr->smbios_entry_point = (RELOCATE_ADDR + *offset);
    *offset += sizeof(smbios_eps_t);

    memcpy_to_virtual(RELOCATE_ADDR + *offset, smbios_eps->table_addr, smbios_eps->table_length);
    smbios_eps->table_addr = (uint32_t)RELOCATE_ADDR + *offset;

    memcpy_to_virtual(draumr_hdr->smbios_entry_point, (uint32_t)smbios_eps, sizeof(smbios_eps_t));
    *offset += smbios_eps->table_length;
}

/* Finds the length of the SMBIOS tables, for use by 'smbios_table_relocate' to build the neccessary structures */
size_t smbios_table_length(uint32_t smbios)
{
    smbios_eps_t *smbios_eps = NULL;
    uint32_t length = 0;

    if(!smbios)
	return length;

    length += sizeof(smbios_eps_t);

    smbios_eps = (smbios_eps_t*)smbios;
    length += smbios_eps->table_length;

    return length;
}
