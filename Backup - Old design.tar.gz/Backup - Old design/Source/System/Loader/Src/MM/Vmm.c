/* VMM common functions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Types.h>
#include <Kprintf.h>
#include <MM/Vmm.h>
#include <MM/Pmm.h>

static vmm_if_t* vmm_if = NULL;

// Initializes the Virtual Memory Manager, and enables paging.
void vmm_init(uint8_t type)
{
    switch(type)
    {
	case KERNEL_LEGACY:
	    vmm_if = vmm_leg_init();
	    break;

	case KERNEL_PAE:
	    vmm_if = vmm_pae_init();
	    break;

	case KERNEL_LONG:
	    vmm_if = vmm_long_init();
	    break;

	default:
	    PANIC("Unknown VMM type");
	    break;
    }
}

void vmm_alloc_frame(uint64_t addr, uint32_t flags)
{
    vmm_if->alloc_frame(addr, flags);
}

void vmm_map_frame(uint64_t addr, uint64_t phys, uint32_t flags)
{
    vmm_if->map_frame(addr, phys, flags);
}

void vmm_free_frame(uint64_t addr)
{
    vmm_if->free_frame(addr);
}

void memcpy_to_virtual(uint64_t dest, uint64_t source, size_t length)
{
    vmm_if->memcpy_to_virtual(dest, source, length);
}

void memset_virtual(uint64_t dest, uint32_t value, size_t length)
{
    vmm_if->memset_virtual(dest, value, length);
}
