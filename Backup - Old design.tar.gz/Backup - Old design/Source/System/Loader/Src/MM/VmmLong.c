/* Long Mode VMM functions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <String.h>
#include <Cpu.h>
#include <Macros.h>
#include <MM/Pmm.h>
#include <MM/Vmm.h>
#include <MM/Paging.h>
#include <Types.h>

static long_pml4_t kernel_pml4 _aligned(PAGE_SIZE);

// Switches the PML4 to the address given.
void switch_pml4(long_pml4_t *new_pml4)
{
    /* Load new CR4. */
    cpu_set_cr4(0x30);

    /* Load new CR3. */
    cpu_set_cr3((reg_t)new_pml4);
}

// Allocates a frame in the virtual address space, and panics if no physical frames are available.
void vmm_long_alloc_frame(uint64_t addr, uint32_t flags)
{
    addr &= 0xFFFFFFFFFFFFF000;

    uint32_t pml4e = (addr & 0xff8000000000) >> 39;
    uint32_t pdpte = (addr & 0x7fc0000000) >> 30;
    uint32_t pde = (addr & 0x3fe00000) >> 21;
    uint32_t pte = (addr & 0x1ff000) >> 12;
    uint64_t *page;

    /* If the PDPT is not present, build it */
    if (!(kernel_pml4.pdpt[pml4e] & PAGE_PRESENT))
    {
        uint32_t pdpt = pmm_frame_alloc();
        kernel_pml4.pdpt[pml4e] = pdpt | PAGE_PRESENT | PAGE_WRITE;
        memset((void*)pdpt, 0, PAGE_SIZE);
    }

    long_pdpt_t *pdpt = (long_pdpt_t*)((uint32_t)kernel_pml4.pdpt[pml4e] & PAGE_MASK);

    /* If the page directory is not present, build it */
    if (!(pdpt->page_dir[pdpte] & PAGE_PRESENT))
    {
        uint32_t pd = pmm_frame_alloc();
        pdpt->page_dir[pdpte] = pd | PAGE_PRESENT | PAGE_WRITE;
        memset((void*)pd, 0, PAGE_SIZE);
    }

    long_page_dir_t *page_dir = (long_page_dir_t*)((uint32_t)pdpt->page_dir[pdpte] & PAGE_MASK);

    /* If the page table of the page directory does not exist, build it */
    if (!(page_dir->page_table[pde] & PAGE_PRESENT))
    {
        uint32_t pt = pmm_frame_alloc();
        page_dir->page_table[pde] = pt | PAGE_PRESENT | PAGE_WRITE;
        memset((void*)pt, 0, PAGE_SIZE);
    }

    long_page_table_t *page_table = (long_page_table_t*)((uint32_t)page_dir->page_table[pde] & PAGE_MASK);

    page = (uint64_t*)&page_table->page[pte];
    *page = pmm_frame_alloc() | flags | PAGE_PRESENT | PAGE_ALLOCATED;
}

// Map a frame in the virtual address space according to the parameter given.
void vmm_long_map_frame(uint64_t addr, uint64_t phys, uint32_t flags)
{
    addr &= 0xFFFFFFFFFFFFF000;

    uint32_t pml4e = (addr & 0xff8000000000) >> 39;
    uint32_t pdpte = (addr & 0x7fc0000000) >> 30;
    uint32_t pde = (addr & 0x3fe00000) >> 21;
    uint32_t pte = (addr & 0x1ff000) >> 12;
    uint64_t *page;

    /* If the PDPT is not present, build it */
    if (!(kernel_pml4.pdpt[pml4e] & PAGE_PRESENT))
    {
        uint32_t pdpt = pmm_frame_alloc();
        kernel_pml4.pdpt[pml4e] = pdpt | PAGE_PRESENT | PAGE_WRITE;
        memset((void*)pdpt, 0, PAGE_SIZE);
    }

    long_pdpt_t *pdpt = (long_pdpt_t*)((uint32_t)kernel_pml4.pdpt[pml4e] & PAGE_MASK);

    /* If the page directory is not present, build it */
    if (!(pdpt->page_dir[pdpte] & PAGE_PRESENT))
    {
        uint32_t pd = pmm_frame_alloc();
        pdpt->page_dir[pdpte] = pd | PAGE_PRESENT | PAGE_WRITE;
        memset((void*)pd, 0, PAGE_SIZE);
    }

    long_page_dir_t *page_dir = (long_page_dir_t*)((uint32_t)pdpt->page_dir[pdpte] & PAGE_MASK);

    /* If the page table of the page directory does not exist, build it */
    if (!(page_dir->page_table[pde] & PAGE_PRESENT))
    {
        uint32_t pt = pmm_frame_alloc();
        page_dir->page_table[pde] = pt | PAGE_PRESENT | PAGE_WRITE;
        memset((void*)pt, 0, PAGE_SIZE);
    }

    long_page_table_t *page_table = (long_page_table_t*)((uint32_t)page_dir->page_table[pde] & PAGE_MASK);

    page = (uint64_t*)&page_table->page[pte];
    *page = phys | flags | PAGE_PRESENT;
}

// Frees a frame in the virtual address space.
void vmm_long_free_frame(uint64_t addr)
{
    addr &= 0xFFFFFFFFFFFFF000;

    uint32_t pml4e = (addr & 0xff8000000000) >> 39;
    uint32_t pdpte = (addr & 0x7fc0000000) >> 30;
    uint32_t pde = (addr & 0x3fe00000) >> 21;
    uint32_t pte = (addr & 0x1ff000) >> 12;
    uint64_t *page;

    /* If the PDPT is not present, build it */
    if (!(kernel_pml4.pdpt[pml4e] & PAGE_PRESENT))
	return;

    long_pdpt_t *pdpt = (long_pdpt_t*)((uint32_t)kernel_pml4.pdpt[pml4e] & PAGE_MASK);

    if (!(pdpt->page_dir[pdpte] & PAGE_PRESENT))
        return;

    long_page_dir_t *page_dir = (long_page_dir_t*)((uint32_t)pdpt->page_dir[pdpte] & PAGE_MASK);

    if (!(page_dir->page_table[pde] & PAGE_PRESENT))
        return;

    long_page_table_t *page_table = (long_page_table_t*)((uint32_t)page_dir->page_table[pde] & PAGE_MASK);

    page = (uint64_t*)&page_table->page[pte];
    if (!(*page & PAGE_PRESENT))
        return;

    if (*page & PAGE_ALLOCATED)
	pmm_frame_free(*page & PAGE_MASK);

    *page = (uint64_t)0x00000000;
}

void vmm_long_memcpy_to_virtual(uint64_t dest, uint64_t source, size_t length)
{
    ptr_t i, j;
    for(i = 0, j = length; i < j; i += PAGE_SIZE)
    {
        uint32_t pml4e = (dest & 0xff8000000000) >> 39;
        uint32_t pdpte = (dest & 0x7fc0000000) >> 30;
        uint32_t pde = (dest & 0x3fe00000) >> 21;
        uint32_t pte = (dest & 0x1ff000) >> 12;
        uint64_t *page;

        /* If the PDPT is not present, build it */
        if (!(kernel_pml4.pdpt[pml4e] & PAGE_PRESENT))
	    return;

        long_pdpt_t *pdpt = (long_pdpt_t*)((uint32_t)kernel_pml4.pdpt[pml4e] & PAGE_MASK);

        if (!(pdpt->page_dir[pdpte] & PAGE_PRESENT))
            return;

        long_page_dir_t *page_dir = (long_page_dir_t*)((uint32_t)pdpt->page_dir[pdpte] & PAGE_MASK);

        if (!(page_dir->page_table[pde] & PAGE_PRESENT))
            return;

        long_page_table_t *page_table = (long_page_table_t*)((uint32_t)page_dir->page_table[pde] & PAGE_MASK);

        page = (uint64_t*)&page_table->page[pte];
        if (!(*page & PAGE_PRESENT))
            return;

        uint32_t phys_dest = (*page & PAGE_MASK);
        phys_dest += (dest & 0xFFF);
        uint32_t to_copy;

        if (!(length & 0xFFF))
        {
	    to_copy = 0x1000;
            length -= 0x1000;
        }

        else
        {
            to_copy = length & 0xFFF;
            length -= to_copy;
        }

        memcpy((void*)phys_dest, (void*)(uint32_t)source, to_copy);
        source += to_copy;
        dest += to_copy;
    }
}

void vmm_long_memset_virtual(uint64_t dest, uint32_t value, size_t length)
{
    ptr_t i, j;
    for(i = 0, j = length; i < j; i += PAGE_SIZE)
    {
        uint32_t pml4e = (dest & 0xff8000000000) >> 39;
        uint32_t pdpte = (dest & 0x7fc0000000) >> 30;
        uint32_t pde = (dest & 0x3fe00000) >> 21;
        uint32_t pte = (dest & 0x1ff000) >> 12;
        uint64_t *page;

        /* If the PDPT is not present, build it */
        if (!(kernel_pml4.pdpt[pml4e] & PAGE_PRESENT))
	    return;

        long_pdpt_t *pdpt = (long_pdpt_t*)((uint32_t)kernel_pml4.pdpt[pml4e] & PAGE_MASK);

        if (!(pdpt->page_dir[pdpte] & PAGE_PRESENT))
            return;

        long_page_dir_t *page_dir = (long_page_dir_t*)((uint32_t)pdpt->page_dir[pdpte] & PAGE_MASK);

        if (!(page_dir->page_table[pde] & PAGE_PRESENT))
            return;

        long_page_table_t *page_table = (long_page_table_t*)((uint32_t)page_dir->page_table[pde] & PAGE_MASK);

        page = (uint64_t*)&page_table->page[pte];
        if (!(*page & PAGE_PRESENT))
            return;

        uint32_t phys_dest = (*page & PAGE_MASK);
        phys_dest += (dest & 0xFFF);
        uint32_t to_set;

        if (!(length & 0xFFF))
        {
	    to_set = 0x1000;
            length -= 0x1000;
        }

        else
        {
            to_set = length & 0xFFF;
            length -= to_set;
        }

        memset((void*)phys_dest, value, to_set);
        dest += to_set;
    }
}

static vmm_if_t vmm_long_if =
{
    .alloc_frame = vmm_long_alloc_frame,
    .map_frame = vmm_long_map_frame,
    .free_frame = vmm_long_free_frame,
    .memcpy_to_virtual = vmm_long_memcpy_to_virtual,
    .memset_virtual = vmm_long_memset_virtual
};

// Initializes the LONG MODE VMM, and starts up paging.
vmm_if_t* vmm_long_init()
{
    long_pdpt_t *pdpt;
    long_page_dir_t *page_dir;
    long_page_table_t *page_table;
    uint32_t tmp;

    memset((void*)&kernel_pml4, 0, sizeof(long_pml4_t));

    /* Map the last entry of the PML4 to itself, thus effectively creating a self mapped environment */
    kernel_pml4.pdpt[511] = (uint32_t)&kernel_pml4 | PAGE_PRESENT | PAGE_WRITE;

    /* Allocate the PDPT to identity map the Loader */
    tmp = pmm_frame_alloc();
    kernel_pml4.pdpt[0] = tmp | PAGE_PRESENT | PAGE_WRITE;
    pdpt = (long_pdpt_t*)tmp;
    memset(pdpt, 0, sizeof(long_pdpt_t));

    /* Allocate the Page Directory to identity map the Loader */
    tmp = pmm_frame_alloc();
    pdpt->page_dir[0] = tmp | PAGE_PRESENT | PAGE_WRITE;
    page_dir = (long_page_dir_t*)tmp;
    memset(page_dir, 0, sizeof(long_page_dir_t));

    /* Allocate the Page Table to identity map the Loader */
    tmp = pmm_frame_alloc();
    page_dir->page_table[0] = tmp | PAGE_PRESENT | PAGE_WRITE;
    page_table = (long_page_table_t*)tmp;
    memset(page_table, 0, sizeof(long_page_table_t));

    /* Map 0x100000 - 0x180000 into the table */
    for (ptr_t i = 0x100000; i < 0x180000; i += 0x1000)
        page_table->page[i>>12] = i | PAGE_PRESENT | PAGE_WRITE;

    switch_pml4(&kernel_pml4);
    
    return &vmm_long_if;
}
