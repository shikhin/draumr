/* PAE VMM functions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <String.h>
#include <Cpu.h>
#include <MM/Pmm.h>
#include <MM/Vmm.h>
#include <MM/Paging.h>
#include <Macros.h>
#include <Types.h>

static pae_pdpt_t kernel_pdpt _aligned(32);

// Switches the page directory pointer table to the pdpt given.
void switch_pdpt(pae_pdpt_t *new_pdpt)
{
    /* Load new CR3. */
    cpu_set_cr3((reg_t)new_pdpt);

    /* Load new CR4. */
    cpu_set_cr4(0x30);
}

// Allocates a frame in the virtual address space, and panics if no physical frames are available.
void vmm_pae_alloc_frame(uint64_t addr, uint32_t flags)
{
    addr &= PAGE_MASK;

    uint32_t pdpte = (uint32_t)addr >> 30;
    uint32_t pde = ((uint32_t)addr << 2) >> 23;
    uint32_t pte = ((uint32_t)addr << 11) >> 23;
    uint64_t *page;

    /* If the page directory is not present, build it */
    if ((kernel_pdpt.page_dir[pdpte] & PAGE_PRESENT) == 0)
    {
        uint32_t pd = pmm_frame_alloc();
        kernel_pdpt.page_dir[pdpte] = pd | PAGE_PRESENT | PAGE_WRITE;
        
        pae_page_dir_t *page_dir_self = (pae_page_dir_t*)((uint32_t)kernel_pdpt.page_dir[3] & PAGE_MASK);
        page_dir_self->page_table[508 + pdpte] = kernel_pdpt.page_dir[pdpte];

        memset((void*)pd, 0, PAGE_SIZE);
    }

    pae_page_dir_t *page_dir = (pae_page_dir_t*)((uint32_t)kernel_pdpt.page_dir[pdpte] & PAGE_MASK);

    /* If the page table of the page directory does not exist, build it */
    if (!(page_dir->page_table[pde] & PAGE_PRESENT))
    {
        uint32_t pt = pmm_frame_alloc();
        page_dir->page_table[pde] = pt | PAGE_PRESENT | PAGE_WRITE;
        memset((void*)pt, 0, PAGE_SIZE);
    }

    pae_page_table_t *page_table = (pae_page_table_t*)((uint32_t)page_dir->page_table[pde] & PAGE_MASK);

    page = (uint64_t*)&page_table->page[pte];
    *page = pmm_frame_alloc() | flags | PAGE_PRESENT | PAGE_ALLOCATED;
}

// Map a frame in the virtual address space according to the parameter given.
void vmm_pae_map_frame(uint64_t addr, uint64_t phys, uint32_t flags)
{
    addr &= PAGE_MASK;

    uint32_t pdpte = (uint32_t)addr >> 30;
    uint32_t pde = ((uint32_t)addr << 2) >> 23;
    uint32_t pte = ((uint32_t)addr << 11) >> 23;
    uint64_t *page;

    /* If the page directory is not present, build it */
    if ((kernel_pdpt.page_dir[pdpte] & PAGE_PRESENT) == 0)
    {
        uint32_t pd = pmm_frame_alloc();
        kernel_pdpt.page_dir[pdpte] = pd | PAGE_PRESENT | PAGE_WRITE;
        
        pae_page_dir_t *page_dir_self = (pae_page_dir_t*)((uint32_t)kernel_pdpt.page_dir[3] & PAGE_MASK);
        page_dir_self->page_table[508 + pdpte] = kernel_pdpt.page_dir[pdpte];

        memset((void*)pd, 0, PAGE_SIZE);
    }

    pae_page_dir_t *page_dir = (pae_page_dir_t*)((uint32_t)kernel_pdpt.page_dir[pdpte] & PAGE_MASK);

    /* If the page table of the page directory does not exist, build it */
    if (!(page_dir->page_table[pde] & PAGE_PRESENT))
    {
        uint32_t pt = pmm_frame_alloc();
        page_dir->page_table[pde] = pt | PAGE_PRESENT | PAGE_WRITE;
        memset((void*)pt, 0, PAGE_SIZE);
    }

    pae_page_table_t *page_table = (pae_page_table_t*)((uint32_t)page_dir->page_table[pde] & PAGE_MASK);

    page = (uint64_t*)&page_table->page[pte];
    *page = phys | flags | PAGE_PRESENT;
}

// Frees a frame in the virtual address space.
void vmm_pae_free_frame(uint64_t addr)
{
    addr &= PAGE_MASK;

    uint32_t pdpte = (uint32_t)addr >> 30;
    uint32_t pde = ((uint32_t)addr << 2) >> 23;
    uint32_t pte = ((uint32_t)addr << 11) >> 23;
    uint64_t *page;

    if (!(kernel_pdpt.page_dir[pdpte] & PAGE_PRESENT))
        return;

    pae_page_dir_t *page_dir = (pae_page_dir_t*)((uint32_t)kernel_pdpt.page_dir[pdpte] & PAGE_MASK);

    if (!(page_dir->page_table[pde] & PAGE_PRESENT))
        return;

    pae_page_table_t *page_table = (pae_page_table_t*)((uint32_t)page_dir->page_table[pde] & PAGE_MASK);

    page = (uint64_t*)&page_table->page[pte];
    if (!(*page & PAGE_PRESENT))
        return;

    if (*page & PAGE_ALLOCATED)
	pmm_frame_free(*page & PAGE_MASK);

    *page = (uint64_t)0x00000000;
}

void vmm_pae_memcpy_to_virtual(uint64_t dest, uint64_t source, size_t length)
{
    ptr_t i, j;
    for(i = 0, j = length; i < j; i += PAGE_SIZE)
    {
        uint32_t pdpte = (uint32_t)dest >> 30;
        uint32_t pde = ((uint32_t)dest << 2) >> 23;
        uint32_t pte = ((uint32_t)dest << 11) >> 23;
        uint64_t *page;

        if (!(kernel_pdpt.page_dir[pdpte] & PAGE_PRESENT))
            return;

        pae_page_dir_t *page_dir = (pae_page_dir_t*)((uint32_t)kernel_pdpt.page_dir[pdpte] & PAGE_MASK);

        if (!(page_dir->page_table[pde] & PAGE_PRESENT))
            return;

        pae_page_table_t *page_table = (pae_page_table_t*)((uint32_t)page_dir->page_table[pde] & PAGE_MASK);

        page = (uint64_t*)&page_table->page[pte];
        if (!(*page & PAGE_PRESENT))
            return;

        uint32_t phys_dest = (*page & PAGE_MASK);
        phys_dest += (dest & 0xFFF);
        uint32_t to_copy;

        if (!(length & 0xFFF))
        {
	    to_copy = 0x1000;
            length -= 0x1000;
        }

        else
        {
            to_copy = length & 0xFFF;
            length -= to_copy;
        }

        memcpy((void*)phys_dest, (void*)(uint32_t)source, to_copy);
        source += to_copy;
        dest += to_copy;
    }
}

void vmm_pae_memset_virtual(uint64_t dest, uint32_t value, size_t length)
{
    ptr_t i, j;
    for(i = 0, j = length; i < j; i += PAGE_SIZE)
    {
        uint32_t pdpte = (uint32_t)dest >> 30;
        uint32_t pde = ((uint32_t)dest << 2) >> 23;
        uint32_t pte = ((uint32_t)dest << 11) >> 23;
        uint64_t *page;

        if (!(kernel_pdpt.page_dir[pdpte] & PAGE_PRESENT))
            return;

        pae_page_dir_t *page_dir = (pae_page_dir_t*)((uint32_t)kernel_pdpt.page_dir[pdpte] & PAGE_MASK);

        if (!(page_dir->page_table[pde] & PAGE_PRESENT))
            return;

        pae_page_table_t *page_table = (pae_page_table_t*)((uint32_t)page_dir->page_table[pde] & PAGE_MASK);

        page = (uint64_t*)&page_table->page[pte];
        if (!(*page & PAGE_PRESENT))
            return;

        uint32_t phys_dest = (*page & PAGE_MASK);
	phys_dest += (dest & 0xFFF);
        uint32_t to_set;

        if (!(length & 0xFFF))
        {
	    to_set = 0x1000;
            length -= 0x1000;
        }

        else
        {
            to_set = length & 0xFFF;
	    length -= to_set;
        }

        memset((void*)phys_dest, value, to_set);
        dest += to_set;
    }
}


static vmm_if_t vmm_pae_if =
{
    .alloc_frame = vmm_pae_alloc_frame,
    .map_frame = vmm_pae_map_frame,
    .free_frame = vmm_pae_free_frame,
    .memcpy_to_virtual = vmm_pae_memcpy_to_virtual,
    .memset_virtual = vmm_pae_memset_virtual
};

// Initializes the PAE VMM, and starts up paging.
vmm_if_t* vmm_pae_init()
{
    ptr_t tmp;
    pae_page_dir_t *page_dir[2];
    pae_page_table_t *kernel_table;

    /* You could allocate a frame over here, but in the _map and _alloc functions
     * it assumes that kernel_pdpt is already mapped into the virtual address space. However, it
     * isn't. You can't even call _map and _alloc to map kernel_pdpt. This can be fixed by manually mapping
     * kernel_pdpt before paging is initialized.
     * NOTE: This can also be fixed by not allocating it and moving it to the .data section of the Loader ;-) */
    memset(&kernel_pdpt, 0, sizeof(pae_pdpt_t));

    /* Defines the last page directory, which is required for the Self Mapping table */
    tmp = pmm_frame_alloc();
    kernel_pdpt.page_dir[3] = tmp | PAGE_PRESENT;
    page_dir[1] = (pae_page_dir_t*)tmp;
    memset(page_dir[1], 0, PAGE_SIZE);
    page_dir[1]->page_table[511] = tmp | PAGE_PRESENT | PAGE_WRITE;

    /* Defines the first page directory for the loader's code and data region */
    tmp = pmm_frame_alloc();
    kernel_pdpt.page_dir[0] = tmp | PAGE_PRESENT;
    page_dir[0] = (pae_page_dir_t*)tmp;
    memset(page_dir[0], 0, PAGE_SIZE);
    page_dir[1]->page_table[508] = tmp | PAGE_PRESENT | PAGE_WRITE;

    /* Defines a page table for the page directory to identity map the required region */
    tmp = pmm_frame_alloc();
    page_dir[0]->page_table[0] = tmp | PAGE_PRESENT | PAGE_WRITE;
    kernel_table = (pae_page_table_t*)tmp;
    memset(kernel_table, 0, PAGE_SIZE);

    for (ptr_t i = 0x100000; i < 0x180000; i += PAGE_SIZE)
        kernel_table->page[i>>12] = i | PAGE_PRESENT | PAGE_WRITE;

    switch_pdpt(&kernel_pdpt);

    return &vmm_pae_if;
}
