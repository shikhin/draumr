/* Physical memory manager functions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Types.h>
#include <String.h>
#include <Kprintf.h>
#include <MM/Pmm.h>
#include <MP/Acpi.h>
#include <String.h>

#include <Lib/Bitmap.h>

#define FRAME_COUNT     (PMM_MAX_MEMORY / PAGE_SIZE)
#define FRAME_DATA_SIZE (FRAME_COUNT / 32)

static bitmap_t frame_map;
//static uint32_t frame_data[FRAME_DATA_SIZE];
static srat_t *srat;

extern int __loader_start;
extern int __loader_end;

// Initializes the physical memory manager, and returns the total amount of memory.
uint64_t pmm_init()
{
    mmap_base_t *mmap_base = pmm_mmap_init();
    uint32_t first_entry = (uint32_t)mmap_base + sizeof(mmap_base_t);
    for(uint32_t i = 0; i < mmap_base->entries; i++)
    {
	mmap_entry_t *mmap_entry = (mmap_entry_t*)first_entry;
	mmap_entry += i;
	kprintf("Base address: 0x%x Length: 0x%x Type: %d Flags: %d NUMA ID: %d\n", (uint32_t)mmap_entry->base_addr, (uint32_t)mmap_entry->length,
			 mmap_entry->type, mmap_entry->flags, mmap_entry->numa_id);
    }
    for(;;);    
    return 0;
    /*
    mb_mmap_t* mmap;
    uint64_t mem_total = 0;

    if (!(mb_info->flags & MB_INFO_FLAGS_MMAP))
        PANIC("You don't even get me a memory map?");

    numa_bsp_mem_range();

    memsetd(frame_data, 0xffffffff, FRAME_DATA_SIZE);
    bitmap_init_buf(&frame_map, FRAME_COUNT, frame_data);

    mmap = (mb_mmap_t*)mb_info->mmap_addr;

    while ((uint32_t)mmap < (mb_info->mmap_addr + mb_info->mmap_length))
    {
        mem_total += mmap->len;

        * Since we are only keeping track of the first 16MiB, we won't need to parse the rest of it,
         * but we have to get the total amount of memory *
        if (mmap->addr >= PMM_MAX_MEMORY)
        {
            mmap = (mb_mmap_t*)((uint32_t)mmap + mmap->size + sizeof(uint32_t));
            continue;
        }

        uint32_t first_page = mmap->addr / PAGE_SIZE;
        uint32_t last_page = (mmap->addr + mmap->len - 1) / PAGE_SIZE;
        last_page = MIN(last_page, (PMM_MAX_MEMORY - 1) / PAGE_SIZE);

        if (mmap->type == MEM_AVAILABLE)
        {
            * Clear the first few 'odd' pages *
            while ((first_page & 31) && (first_page < last_page))
            {
                bitmap_clear(&frame_map, first_page);
                first_page++;
            }

            * Split the remaining pages into groups of 32 so that it can all be done by a
             * stosl *
            uint32_t total_dwords = (last_page - first_page) / 32;
            memsetd(&(frame_map.buffer[INDEX_FROM_BIT(first_page)]), 0, total_dwords);
            first_page += (total_dwords * 32);

            * Clear the last few 'odd' pages *
            while (first_page < last_page)
            {
                bitmap_clear(&frame_map, first_page);
                first_page++;
            }
        }

        mmap = (mb_mmap_t*)((uint32_t)mmap + mmap->size + sizeof(uint32_t));
    }

    * Reserve memory under 1Mb. *
    for (size_t i = 0; i < (0x100000 / PAGE_SIZE); ++i)
        bitmap_set(&frame_map, i);

    * Reserve memory containing the loader itself. *
    ptr_t l_start = (ptr_t)&__loader_start;
    ptr_t l_end = (ptr_t)&__loader_end;
    for (size_t i = l_start / PAGE_SIZE; i < ((l_end / PAGE_SIZE) + 1); ++i)
        bitmap_set(&frame_map, i);

    return mem_total;
    */
}

// Parses the memory map initiated by the Intermediate Loader, and merges information provided by SRAT with it.
mmap_base_t *pmm_mmap_init()
{
    mmap_base_t *mmap_base = (mmap_base_t*)0x9000;
    if(!mmap_base->type)
	PANIC("Unable to get memory map on this machine");
   
    uint32_t size = (mmap_base->entries * sizeof(mmap_entry_t)) + sizeof(mmap_base_t);
   
    memcpy(&mmap_space, (void*)0x9000, size);
    mmap_base = (mmap_base_t*)&mmap_space;

    srat = acpi_table_find("SRAT");
    if(!srat)    
        return mmap_base;

    pmm_merge_srat(mmap_base);
    return mmap_base;
}

// Merges the memory map with the SRAT.
void pmm_merge_srat(mmap_base_t *mmap_base)
{
    uint32_t first_entry = (uint32_t)mmap_base + sizeof(mmap_base_t);
    for(uint32_t i = 0; i < mmap_base->entries; i++)
    {
	mmap_entry_t *mmap_entry = (mmap_entry_t*)first_entry;
        mmap_entry += i;
	for(uint8_t *type = (uint8_t*)&srat->type;
	    (uint32_t)type < ((uint32_t)srat + srat->header.length);)
	{
	    if(*type == 0)
	    {
		srat_lapic_t *srat_lapic = (srat_lapic_t*)type;
		type += srat_lapic->length;
	    }

	    else if(*type == 1)
	    {
		srat_mem_t *srat_mem = (srat_mem_t*)type;
		type += srat_mem->length;

		uint64_t end_addr = mmap_entry->base_addr;
	        end_addr += mmap_entry->length;
		uint64_t dom_end_addr = srat_mem->base_addr;
	        dom_end_addr += srat_mem->region_length;

		if((mmap_entry->base_addr >= srat_mem->base_addr) &&
		   (mmap_entry->base_addr < dom_end_addr))
		{
		    if(end_addr > dom_end_addr)
		    {
			mmap_entry_t *mmap_last = (mmap_entry_t*)first_entry;
			mmap_last += mmap_base->entries;
			
			uint64_t extra = end_addr - dom_end_addr;
			mmap_entry->length -= extra;

			mmap_last->base_addr = (mmap_entry->base_addr + mmap_entry->length);
			mmap_last->length = extra;
			mmap_last->type = mmap_entry->type;
			mmap_last->flags = mmap_entry->flags;
			mmap_base->entries++;
		    }

		    mmap_entry->numa_id = srat_mem->numa_id;
		}
	    }

	    else 
	    {
		srat_x2apic_t *srat_x2apic = (srat_x2apic_t*)type;
		type += srat_x2apic->length;
	    }
	}
    }
}

// Finds the first free frame, allocates it, and returns its address.
ptr_t pmm_frame_alloc()
{
    size_t idx;

    if (!bitmap_first_free(&frame_map, &idx))
        PANIC("No free frames left");

    bitmap_set(&frame_map, idx);

    return (idx * PAGE_SIZE);
}

// Sets a physical frame as free in the bitset.
void pmm_frame_free(ptr_t p)
{
    uint32_t idx = p / PAGE_SIZE;

    if (idx >= FRAME_COUNT)
        return;

    if (!bitmap_is_set(&frame_map, idx))
        return;

    bitmap_clear(&frame_map, idx);
}

// Sets a physical frame as used in the bitset.
void pmm_frame_set(ptr_t p)
{
    uint32_t idx = p / PAGE_SIZE;

    if (idx >= FRAME_COUNT)
        return;

    bitmap_set(&frame_map, idx);
}

// Sets a range of physical memory as used in the bitset.
void pmm_frame_range_set(ptr_t start, ptr_t end)
{
    size_t first_page = (start & PAGE_MASK) / PAGE_SIZE;
    size_t last_page = ((end + PAGE_SIZE - 1) & PAGE_MASK) / PAGE_SIZE;

    while ((first_page & 31) && (first_page < last_page))
    {
        bitmap_set(&frame_map, first_page);
        first_page++;
    }

    /* Split the remaining pages into groups of 32 so that it can all be done by a
     * stosl */
    uint32_t total_dwords = (last_page - first_page) / 32;
    memsetd(&(frame_map.buffer[INDEX_FROM_BIT(first_page)]), 0xffffffff, total_dwords);
    first_page += (total_dwords * 32);

    /* Set the last few 'odd' pages */
    while (first_page < last_page)
    {
        bitmap_set(&frame_map, first_page);
        first_page++;
    }
}
