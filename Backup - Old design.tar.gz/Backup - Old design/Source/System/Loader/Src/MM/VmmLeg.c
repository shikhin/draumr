/* Legacy VMM functions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <String.h>
#include <Cpu.h>
#include <Macros.h>
#include <MM/Pmm.h>
#include <MM/Vmm.h>
#include <MM/Paging.h>
#include <Types.h>

static leg_page_dir_t kernel_page_dir _aligned(PAGE_SIZE);

// Switches the page directory to the page dir given.
static inline void vmm_leg_enable_paging(leg_page_dir_t *new_dir)
{
    /* Set the address of the new page directory. */
    cpu_set_cr3((reg_t)new_dir);
}

// Allocates a frame in the virtual address space, and panics if no physical frames are available.
static void vmm_leg_alloc_frame(uint64_t addr, uint32_t flags)
{
    addr &= PAGE_MASK;

    uint32_t pde = ((uint32_t)addr / 0x1000) / 1024;
    uint32_t pte = ((uint32_t)addr / 0x1000) % 1024;
    uint32_t *page;

    /* If the table we require isn't present, build it */
    if ((kernel_page_dir.page_table[pde] & PAGE_PRESENT) == 0)
    {
        uint32_t pt = pmm_frame_alloc();
        kernel_page_dir.page_table[pde] = pt | flags | PAGE_PRESENT;
        memset((void*)pt, 0, PAGE_SIZE);
    }

    leg_page_table_t* page_table = (leg_page_table_t*)((uint32_t)kernel_page_dir.page_table[pde] & PAGE_MASK);
    page = (uint32_t*)&page_table->page[pte];
    *page = pmm_frame_alloc() | flags | PAGE_PRESENT | PAGE_ALLOCATED;
}

// Map a frame in the virtual address space according to the parameter given.
static void vmm_leg_map_frame(uint64_t addr, uint64_t phys, uint32_t flags)
{
    addr &= PAGE_MASK;

    uint32_t pde = (addr / 0x1000) / 1024;
    uint32_t pte = (addr / 0x1000) % 1024;
    uint32_t *page;

    /* If the table we require isn't present, build it */
    if ((kernel_page_dir.page_table[pde] & PAGE_PRESENT) == 0)
    {
        uint32_t pt = pmm_frame_alloc();
        kernel_page_dir.page_table[pde] = pt | flags | PAGE_PRESENT;
        memset((void*)pt, 0, PAGE_SIZE);
    }

    leg_page_table_t* page_table = (leg_page_table_t*)((uint32_t)kernel_page_dir.page_table[pde] & PAGE_MASK);
    page = (uint32_t*)&page_table->page[pte];
    *page = phys | flags | PAGE_PRESENT;
}

// Frees a frame in the virtual address space.
static void vmm_leg_free_frame(uint64_t addr)
{
    uint32_t pde = ((uint32_t)addr / 0x1000) / 1024;
    uint32_t pte = ((uint32_t)addr / 0x1000) % 1024;
    uint32_t *page;

    /* If the table isn't present, we can simply return */
    if ((kernel_page_dir.page_table[pde] & PAGE_PRESENT) == 0)
        return;

    leg_page_table_t *page_table = (leg_page_table_t*)(kernel_page_dir.page_table[pde] & PAGE_MASK);
    page = (uint32_t*)&page_table->page[pte];
    if (!(*page & PAGE_PRESENT))
        return;

    if (*page & PAGE_ALLOCATED)
	pmm_frame_free(*page & PAGE_MASK);

    *page = (uint32_t)0x00000000;
}

void vmm_leg_memcpy_to_virtual(uint64_t dest, uint64_t source, size_t length)
{
    ptr_t i, j;
    for(i = 0, j = length; i < j; i += PAGE_SIZE)
    {
        uint32_t pde = ((uint32_t)dest / 0x1000) / 1024;
        uint32_t pte = ((uint32_t)dest / 0x1000) % 1024;
        uint32_t *page;

        /* If the table isn't present, we can simply return */
        if ((kernel_page_dir.page_table[pde] & PAGE_PRESENT) == 0)
            return;

        leg_page_table_t *page_table = (leg_page_table_t*)(kernel_page_dir.page_table[pde] & PAGE_MASK);
        page = (uint32_t*)&page_table->page[pte];
        if (!(*page & PAGE_PRESENT))
            return;

        uint32_t phys_dest = (*page & PAGE_MASK);
	phys_dest += (dest & 0xFFF);
        uint32_t to_copy;

        if (!(length & 0xFFF))
        {
	    to_copy = 0x1000;
            length -= 0x1000;
        }

        else
        {
            to_copy = length & 0xFFF;
            length -= to_copy;
        }

        memcpy((void*)phys_dest, (void*)(uint32_t)source, to_copy);
        source += to_copy;
        dest += to_copy;
    }
}


void vmm_leg_memset_virtual(uint64_t dest, uint32_t value, size_t length)
{
    ptr_t i, j;
    for(i = 0, j = length; i < j; i += PAGE_SIZE)
    {
        uint32_t pde = ((uint32_t)dest / 0x1000) / 1024;
        uint32_t pte = ((uint32_t)dest / 0x1000) % 1024;
        uint32_t *page;

        /* If the table isn't present, we can simply return */
        if ((kernel_page_dir.page_table[pde] & PAGE_PRESENT) == 0)
            return;

        leg_page_table_t *page_table = (leg_page_table_t*)(kernel_page_dir.page_table[pde] & PAGE_MASK);
        page = (uint32_t*)&page_table->page[pte];
        if (!(*page & PAGE_PRESENT))
            return;

        uint32_t phys_dest = (*page & PAGE_MASK);
	phys_dest += (dest & 0xFFF);
        uint32_t to_set;

        if (!(length & 0xFFF))
        {
	    to_set = 0x1000;
            length -= 0x1000;
        }

        else
        {
            to_set = length & 0xFFF;
            length -= to_set;
        }

        memset((void*)phys_dest, value, to_set);
        dest += to_set;
    }
}

static vmm_if_t vmm_leg_if =
{
    .alloc_frame = vmm_leg_alloc_frame,
    .map_frame = vmm_leg_map_frame,
    .free_frame = vmm_leg_free_frame,
    .memcpy_to_virtual = vmm_leg_memcpy_to_virtual,
    .memset_virtual = vmm_leg_memset_virtual
};

// Initializes the Legacy VMM, and starts up paging.
vmm_if_t* vmm_leg_init()
{
    ptr_t tmp;
    leg_page_table_t *page_table;

    /* You could allocate a frame over here, but in the _map and _alloc functions
     * it assumes that kernel_page_dir is already mapped into the virtual address space. However, it
     * isn't. You can't even call _map and _alloc to map kernel_page_dir. This can be fixed by manually mapping
     * kernel_page_dir before initializing paging.
     * NOTE: This can also be fixed by making it static */
    memset(&kernel_page_dir, 0, PAGE_SIZE);

    /* Make one page table to identity map the loader's code and data region.
     * This region is taken to be as 0x100000 - 0x180000 throughout */
    tmp = pmm_frame_alloc();
    kernel_page_dir.page_table[0] = tmp | PAGE_PRESENT | PAGE_WRITE;
    page_table = (leg_page_table_t*)tmp;
    memset(page_table, 0, PAGE_SIZE);

    /* Self map the last page table to the page directory, effectively making a self
     * mapped environment */
    kernel_page_dir.page_table[1023] = (ptr_t)&kernel_page_dir | PAGE_PRESENT | PAGE_WRITE;

    for (ptr_t i = 0x100000; i < 0x180000; i += 0x1000)
        page_table->page[i>>12] = i | PAGE_PRESENT | PAGE_WRITE;

    vmm_leg_enable_paging(&kernel_page_dir);

    return &vmm_leg_if;
}
