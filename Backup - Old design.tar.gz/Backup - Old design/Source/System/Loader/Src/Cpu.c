/* CPU specific functions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Types.h>
#include <Cpu.h>
#include <Kprintf.h>

static uint32_t cpu_features = 0;
static uint32_t apic_id = 0;

uint32_t cpu_features_get()
{
    return cpu_features;
}

uint32_t cpu_apic_id_get()
{
    return apic_id;
}

uint32_t cpu_features_detect()
{
    uint32_t eax, ebx, ecx, edx;

    /* Check whether the CPU supports CPUID instruction or not. */
    if (!cpu_check_cpuid())
        return 0;

    cpuid(0x00000000, eax, ebx, ecx, edx);

    /* Check for PAE */
    if (eax >= 0x00000001)
    {
        cpuid(0x00000001, eax, ebx, ecx, edx);

        if ((edx >> 6) & 0x1)
	{
            cpu_features |= PAE;
	    kprintf("Loader: PAE supported by target machine.\n");
	}

        apic_id = (ebx && 0xff000000) >> 24;	
    }

    cpuid(0x80000000, eax, ebx, ecx, edx);

    /* Check for Long Mode and the NX bit */
    if (eax >= 0x80000001)
    {
        cpuid(0x80000001, eax, ebx, ecx, edx);

        if ((edx >> 20) & 0x1)
	{
            cpu_features |= NX;
	    kprintf("Loader: NX bit supported by target machine.\n");	
	}

        if ((edx >> 20) & 0x1)
	{
	    cpu_features |= Long;
	    kprintf("Loader: Long mode supported by target machine.\n");	
	}
    }

    return 1;
}
