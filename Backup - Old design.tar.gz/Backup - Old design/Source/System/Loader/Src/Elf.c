/* ELF loading functions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Kprintf.h>
#include <String.h>
#include <Elf.h>
#include <MM/Pmm.h>
#include <MM/Vmm.h>

// Executes a ELF file, and makes sure the state of the registers are as defined..
void elf_load(void* elf, uint32_t eax, uint32_t ebx, uint32_t args_count, ...)
{
    elf32_ehdr_t *ehdr = (elf32_ehdr_t*)elf;

    if (ehdr->e_ident[0] != 0x7f ||
        ehdr->e_ident[1] != 'E'  ||
        ehdr->e_ident[2] != 'L'  ||
        ehdr->e_ident[3] != 'F')
        PANIC("Error: File not ELF");

    if (ehdr->e_ident[4] != 1)
        PANIC("Error: File not designed for x86-32 architecture");

    if (ehdr->e_ident[5] != 1)
        PANIC("Error: File uses wrong encoding type. LSB ONLY supported");

    /* Parse the program headers, and allocate and map pages as required */
    for (uint32_t i = 0; i < ehdr->e_phnum; i++)
    {
        elf32_phdr_t* phdr = (elf32_phdr_t*)((uint32_t)ehdr + ehdr->e_phoff + (i * ehdr->e_phentsize));

        if (phdr->p_type == PT_LOAD)
        {
            // todo: PAGE_WRITE may not the best idea here as the module could have read-only parts as well
            for (uint32_t j = 0; j < phdr->p_filesz; j += PAGE_SIZE)
                vmm_map_frame(phdr->p_vaddr + j, (ptr_t)ehdr + phdr->p_offset + j, PAGE_WRITE);

            /* In the case of the bss section, the space is not included in the file, and the pages
             * need to be mapped separately */
            if (phdr->p_filesz < phdr->p_memsz)
            {
		uint32_t j = phdr->p_filesz;
                if(j & 0xFFF)
		    j += PAGE_SIZE;

                for (; j < phdr->p_memsz; j += PAGE_SIZE)
                    vmm_alloc_frame(phdr->p_vaddr + j, PAGE_WRITE);

                memset_virtual((uint64_t)(phdr->p_vaddr + phdr->p_filesz), 0, phdr->p_memsz-phdr->p_filesz);
            }
        }
    }

    va_list list;
    va_start(list, args_count);

    /* Map the stack for the kernel being loaded */
    vmm_alloc_frame(0xd0000000, PAGE_WRITE);
    vmm_alloc_frame(0xd0001000, PAGE_WRITE);
    vmm_alloc_frame(0xd0002000, PAGE_WRITE);
    vmm_alloc_frame(0xd0003000, PAGE_WRITE);

    memset_virtual((uint64_t)0xd0000000, 0, 4 * PAGE_SIZE);

    /* Map the screen memory to the proper place. */
    vmm_map_frame(0xdffff000, 0xb8000, PAGE_WRITE);

    /* 'Push' the arguments on to the new stack */
    uint32_t *stack = (uint32_t*)0xd0004000;

    for (uint32_t i = 0; i < args_count; i++)
    {
       uint32_t next_arg;
       next_arg = va_arg(list, uint32_t);
       memcpy_to_virtual((uint32_t)--stack, (uint32_t)&next_arg, sizeof(uint32_t));
    }

    __asm__ __volatile__("mov %0, %%ecx" :: "m" (ehdr->e_entry) : "%ecx");

    /* Load the values in EAX and EBX as specified */
    __asm__ __volatile__("mov %0, %%eax" :: "m" (eax) : "%eax");
    __asm__ __volatile__("mov %0, %%ebx" :: "m" (ebx) : "%ebx");

    /* Load the stack and call the entry point */
    __asm__ __volatile__("mov %0, %%esp" :: "m" (stack) : "%esp");
    __asm__ __volatile__("mov %%cr0, %%edx" ::: "%edx");
    __asm__ __volatile__("or $0x80000000, %%edx" ::: "%edx");
    __asm__ __volatile__("mov %%edx, %%cr0" ::: "%edx");
    
    __asm__ __volatile__("xor %ebp, %ebp");
    __asm__ __volatile__("call *%ecx");
}

// Executes a ELF file, and makes sure the state of the registers are as defined..
void elf_load_64(void* elf, uint32_t eax, uint32_t ebx, uint32_t args_count, ...)
{
    elf64_ehdr_t *ehdr = (elf64_ehdr_t*)elf;

    if (ehdr->e_ident[0] != 0x7f ||
        ehdr->e_ident[1] != 'E'  ||
        ehdr->e_ident[2] != 'L'  ||
        ehdr->e_ident[3] != 'F')
        PANIC("Error: File not ELF");

    if (ehdr->e_ident[4] != 2)
        PANIC("Error: File not designed for AMD64 architecture");

    /* Parse the program headers, and allocate and map pages as required */
    for (uint32_t i = 0; i < ehdr->e_phnum; i++)
    {
        elf64_phdr_t* phdr = (elf64_phdr_t*)((uint32_t)ehdr + (uint32_t)ehdr->e_phoff + (i * ehdr->e_phentsize));
        if (phdr->p_type == PT_LOAD)
        {
            // todo: PAGE_WRITE may not the best idea here as the module could have read-only parts as well
            for (uint32_t j = 0; j < phdr->p_filesz; j += PAGE_SIZE)
                vmm_map_frame(phdr->p_vaddr + j, (uint32_t)ehdr + phdr->p_offset + j, PAGE_WRITE);

            /* In the case of the bss section, the space is not included in the file, and the pages
             * need to be mapped separately */
            if (phdr->p_filesz < phdr->p_memsz)
            {
                uint32_t j = phdr->p_filesz;
                if(j & 0xFFF)
		    j += PAGE_SIZE;

                for (; j < phdr->p_memsz; j += PAGE_SIZE)
                    vmm_alloc_frame(phdr->p_vaddr + j, PAGE_WRITE);
 
                memset_virtual((uint64_t)(phdr->p_vaddr + phdr->p_filesz), 0, phdr->p_memsz-phdr->p_filesz);
            }
        }
    }

    va_list list;
    va_start(list, args_count);

    /* Map the stack for the kernel being loaded */
    vmm_alloc_frame(0xFFFFD00000000000, PAGE_WRITE);
    vmm_alloc_frame(0xFFFFD00000001000, PAGE_WRITE);
    vmm_alloc_frame(0xFFFFD00000002000, PAGE_WRITE);
    vmm_alloc_frame(0xFFFFD00000003000, PAGE_WRITE);

    memset_virtual((uint64_t)0xFFFFD00000000000, 0, 4 * PAGE_SIZE);

    /* Map the screen memory to the proper place. */
    vmm_map_frame(0xFFFFD0000FFFF000, 0xb8000, PAGE_WRITE);

    /* 'Push' the arguments on to the new stack */
    uint64_t stack = (uint64_t)0xFFFFD00000004000;

    for (uint32_t i = 0; i < args_count; i++)
    {
       uint64_t next_arg;
       next_arg = va_arg(list, uint64_t);
       memcpy_to_virtual(stack, (uint32_t)&next_arg, sizeof(uint64_t));
       stack -= sizeof(uint64_t);
    }
   
    uint32_t ptr = (uint32_t)load_long_environment;
    __asm__ __volatile__("mov %0, %%ecx" :: "m" (ehdr->e_entry) : "%ecx");

    /* Load the values in EAX and EBX as specified */
    __asm__ __volatile__("mov %0, %%eax" :: "m" (eax) : "%eax");
    __asm__ __volatile__("mov %0, %%ebx" :: "m" (ebx) : "%ebx");

    __asm__ __volatile__("jmp *%0" :: "m" (ptr));
}
