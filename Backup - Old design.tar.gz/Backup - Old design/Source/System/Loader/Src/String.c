/* Memory and string handling functions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <String.h>

void* memset(void* s, int c, size_t n)
{
    /* Rather than optimizing the function to death, we simply make three cases:
     * CASE I. The count is divisible by 4. We simple use stosl.
     * CASE II. The count is divisible by 2. We use stosw.
     * CASE III. The count isn't divisible by any of the above. We use stosb. */
    
    if (!(n % 4))
    {
	c |= (c << 8);
        c |= (c << 16);
        memsetd(s, c, (n / 4));
    }
    
    else if (!(n % 2))
    {
        c |= (c << 8);
        memsetw(s, c, (n / 2));
    }
    
    else
        memsetb(s, c, n);

    return s;
}

void* memcpy(void* dest, const void* source, size_t count)
{
    /* Rather than optimizing the function to death, we simply make three cases:
     * CASE I. The count is divisible by 4. We simple use movsd.
     * CASE II. The count is divisible by 2. We use movsw.
     * CASE III. The count isn't divisible by any of the above. We use movsb. */

    if (!(count % 4))
        memcpyd(dest, source, (count / 4));

    else if (!(count % 2))
        memcpyw(dest, source, (count / 2));

    else
        memcpyb(dest, source, count);

    return dest;
}

int strcmp(const char* s1, const char* s2)
{
    int r;

    while (1)
    {
        r = *s1 - *s2++;

        if ((r != 0) || (*s1++ == 0))
            break;
    }

    return r;
}

int memcmp(const void* mem1, const void* mem2, size_t c)
{
    reg_t c_reg = 0;
    if(!(c % 4))
    {
        memcmpd(mem1, mem2, (c / 4));
        __asm__ __volatile__("je equal\n \
                              movl $1, %0" : "=m"(c_reg)); 
    } 

    else if(!(c % 2))
    {
        memcmpw(mem1, mem2, (c / 2));
        __asm__ __volatile__("je equal\n \
                              movl $1, %0" : "=m"(c_reg));
    } 

    else
    {
        memcmpb(mem1, mem2, c);
        __asm__ __volatile__("je equal\n \
                              movl $1, %0" : "=m"(c_reg));
    }

    if(c_reg)
    {
        return 0;
    }

    __asm__ __volatile__("equal:");
    return 1;
}
