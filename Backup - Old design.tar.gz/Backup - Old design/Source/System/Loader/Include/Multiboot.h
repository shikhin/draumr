/* Multiboot definitions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_MULTIBOOT_H_
#define _LOADER_MULTIBOOT_H_

#include <Types.h>
#include <Macros.h>

#define MB_LOADER_MAGIC 0x2BADB002

#define MB_INFO_FLAGS_MODS 0x08
#define MB_INFO_FLAGS_MMAP 0x40

typedef struct mb_info mb_info_t;
typedef struct mb_mod  mb_mod_t;

struct mb_info
{
    uint32_t flags;

    uint32_t mem_lower;
    uint32_t mem_upper;

    uint32_t boot_device;
    uint32_t kernel_params;

    uint32_t mod_count;
    uint32_t mod_addr;

    union
    {
        struct
        {
            uint32_t tabsize;
            uint32_t strsize;
            uint32_t addr;
            uint32_t reserved;
        } aout_info;

        struct
        {
            uint32_t num;
            uint32_t size;
            uint32_t addr;
            uint32_t shndx;
        } elf_info;
    } u;

    uint32_t mmap_length;
    uint32_t mmap_addr;
} _packed;

struct mb_mod
{
   uint32_t start_addr;
   uint32_t end_addr;
   uint32_t string;
   uint32_t reserved;
} _packed;

// Finds a module in the modules loaded by GRUB
void module_find(mb_info_t* mb_info, const char* sig, const char* sig_alt, mb_mod_t* mb_mod);

#endif /* _LOADER_MULTIBOOT_H_ */
