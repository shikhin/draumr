/* ELF header definitions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_ELF_H
#define _LOADER_ELF_H

#include <Types.h>
#include <Macros.h>

#define EI_NIDENT 16
#define PT_LOAD 1

typedef struct elf32_ehdr elf32_ehdr_t;
typedef struct elf32_phdr elf32_phdr_t;
typedef struct elf64_ehdr elf64_ehdr_t;
typedef struct elf64_phdr elf64_phdr_t;

struct elf32_ehdr
{
   uint8_t e_ident[EI_NIDENT];
   uint16_t e_type;
   uint16_t e_machine;
   uint32_t e_version;
   uint32_t e_entry;
   uint32_t e_phoff;
   uint32_t e_shoff;
   uint32_t e_flags;
   uint16_t e_ehsize;
   uint16_t e_phentsize;
   uint16_t e_phnum;
   uint16_t e_shentsize;
   uint16_t e_shnum;
   uint16_t e_shstrndx;
} _packed;

struct elf32_phdr
{
   uint32_t p_type;
   uint32_t p_offset;
   uint32_t p_vaddr;
   uint32_t p_paddr;
   uint32_t p_filesz;
   uint32_t p_memsz;
   uint32_t p_flags;
   uint32_t p_align;
} _packed;

struct elf64_ehdr
{
    uint8_t e_ident[EI_NIDENT];
    uint16_t e_type;
    uint16_t e_machine;
    uint32_t e_version;
    uint64_t e_entry;
    uint64_t e_phoff;
    uint64_t e_shoff;
    uint32_t e_flags;
    uint16_t e_ehsize;
    uint16_t e_phentsize;
    uint16_t e_phnum;
    uint16_t e_shentsize;
    uint16_t e_shnum;
    uint16_t e_shstrndx;
} _packed;

struct elf64_phdr
{
    uint32_t p_type;
    uint32_t p_flags;
    uint64_t p_offset;
    uint64_t p_vaddr;
    uint64_t p_paddr;
    uint64_t p_filesz;
    uint64_t p_memsz;
    uint64_t p_align;
} _packed;

// Executes a ELF file, and makes sure the state of the registers are as defined..
void elf_load(void* elf, uint32_t eax, uint32_t ebx, uint32_t args_count, ...);

// Executes a ELF file, and makes sure the state of the registers are as defined..
void elf_load_64(void* elf, uint32_t eax, uint32_t ebx, uint32_t args_count, ...);

extern void load_long_environment();

#endif /* _LOADER_ELF_H */
