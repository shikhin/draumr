/* ACPI definitions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_ACPI_MP_H
#define _LOADER_ACPI_MP_H

#include <Header/Acpi.h>
#include <Types.h>
#include <Macros.h>

typedef struct srat srat_t;
typedef struct slit slit_t;
typedef struct srat_lapic srat_lapic_t;
typedef struct srat_mem srat_mem_t;
typedef struct srat_x2apic srat_x2apic_t;

struct srat
{
    // The SDT header needed to be present in every ACPI table.
    sdt_header_t header;
    
    // Reserved to be 1 for backword compatibility.
    uint32_t reserved_1;
    uint64_t reserved;
 
    // Type of the first Affinity structure.
    uint8_t type;    
} _packed;

struct slit
{
    // The SDT header needs to be present in every ACPI table - as usual.
    sdt_header_t header;

    // The number of NUMA domains.
    uint64_t no_domains;

    // The first entry of the 2D matrix.
    uint8_t first_entry;
} _packed;

struct srat_lapic
{
    uint8_t type;
    uint8_t length;
    uint8_t numa_id_8;
    uint8_t apic_id;
    uint32_t flags;
    uint8_t lsapic_eid;
    uint8_t numa_id_16;
    uint16_t numa_id_32;
    uint32_t clock_domain;
} _packed;

struct srat_mem
{
    uint8_t type;
    uint8_t length;
    uint32_t numa_id;
    uint16_t reserved;
    uint64_t base_addr;
    uint64_t region_length;
    uint32_t reserved_1;
    uint32_t flags;
    uint64_t reserved_2;
} _packed;

struct srat_x2apic
{
    uint8_t type;
    uint8_t length;
    uint16_t reserved;
    uint32_t numa_id;
    uint32_t flags;
    uint32_t clock_domain;
    uint32_t reserved_1;
} _packed;

// Initializes ACPI usage.
void acpi_table_init(uint32_t acpi);

// Finds a ACPI table with signature 'signature'
void *acpi_table_find(char *signature);

#endif /* _LOADER_ACPI_MP_H */
