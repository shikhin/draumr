/* NUMA definitions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_NUMA_MP_H
#define _LOADER_NUMA_MP_H

#include <MP/Acpi.h>
#include <Types.h>
#include <Macros.h>

#include <Lib/Bitmap.h>

typedef struct mem_range mem_range_t;

struct mem_range
{
    uint64_t base_addr;
    uint64_t length;
    uint32_t numa_id;  
};

// Finds a suitabe memory range for the BSPs PMM.
mem_range_t numa_bsp_mem_range();

// Finds the biggest memory range for a specific NUMA ID. If memory is
// not available for that NUMA ID, returns 0 in mem_range->base_addr.
mem_range_t numa_find_mem_range(uint32_t numa_id, srat_t *srat);

#endif /* _LOADER_NUMA_MP_H */
