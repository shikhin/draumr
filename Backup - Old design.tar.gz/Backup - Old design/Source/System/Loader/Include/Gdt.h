/* GDT definitions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_GDT_H
#define _LOADER_GDT_H

#include <Types.h>
#include <Macros.h>

// A GDT gate entry.
typedef struct gdt_gate gdt_gate_t;

struct gdt_gate
{
    uint16_t limit;

    uint16_t baseLow;
    uint8_t baseMiddle;

    uint8_t access;
    uint8_t granularity;

    uint8_t baseHigh;
} _packed;

// The GDT pointer structure to be loaded into GDTR.
typedef struct gdt_ptr gdt_ptr_t;

struct gdt_ptr
{
    uint16_t size;
    uint32_t base;
} _packed;

// Loads the new GDT pointer structure into GDTR.
extern void gdt_flush(uint32_t *gdt_ptr);

// Makes a gdt gate, based on the parameters given.
void gdt_set_gate(uint8_t gate_num, uint32_t base, uint32_t limit, uint8_t access, uint8_t granularity);

// Initializes the GDT, makes three descriptors (NULL, Kernel Code, Kernel Data), and loads it.
void gdt_init();

#endif /* _LOADER_GDT_H */
