/* Memory and string handling functions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_STRING_H_
#define _LOADER_STRING_H_

#include <Types.h>

#define memsetd(s, c, n) __asm__ __volatile__("rep stosl" :: "c" (n), "a" (c), "D" (s))
#define memsetw(s, c, n) __asm__ __volatile__("rep stosw" :: "c" (n), "a" (c), "D" (s))
#define memsetb(s, c, n) __asm__ __volatile__("rep stosb" :: "c" (n), "a" (c), "D" (s))

#define memcpyd(d, s, c) __asm__ __volatile__("rep movsd" :: "c" (c), "S" (s), "D" (d))
#define memcpyw(d, s, c) __asm__ __volatile__("rep movsw" :: "c" (c), "S" (s), "D" (d))
#define memcpyb(d, s, c) __asm__ __volatile__("rep movsb" :: "c" (c), "S" (s), "D" (d))

#define memcmpd(d, s, c) __asm__ __volatile__("repe cmpsd" :: "c" (c), "S" (s), "D" (d))
#define memcmpw(d, s, c) __asm__ __volatile__("repe cmpsw" :: "c" (c), "S" (s), "D" (d))
#define memcmpb(d, s, c) __asm__ __volatile__("repe cmpsb" :: "c" (c), "S" (s), "D" (d))

void* memset(void* s, int c, size_t n);

void* memcpy(void* dest, const void* source, size_t count);

int strcmp(const char* s1, const char* s2);

int memcmp(const void* mem1, const void* mem2, size_t c);

#endif /* _LOADER_STRING_H_ */
