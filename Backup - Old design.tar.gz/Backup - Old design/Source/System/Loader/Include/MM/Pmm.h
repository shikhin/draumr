/* Physical Memory Manager definitions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_PMM_H
#define _LOADER_PMM_H

#include <Types.h>
#include <Macros.h>

#define PAGE_SIZE 4096UL
#define PAGE_MASK (~(PAGE_SIZE - 1))

// Use maximum 16Mb of memory for now.
#define PMM_MAX_MEMORY (0x1000000)

typedef struct mmap_base mmap_base_t;
typedef struct mmap_entry mmap_entry_t;

struct mmap_base
{
    uint32_t type;
    uint32_t entries;
} _packed;

struct mmap_entry
{
    uint64_t base_addr;
    uint64_t length;
    uint32_t type;
    uint32_t flags;
    uint32_t numa_id;
} _packed;

extern ptr_t mmap_space;

// Initializes the physical memory manager, and returns the total amount of memory.
uint64_t pmm_init();

// Parses the memory map initiated by the Loader, merges SRAT with it and returns.
mmap_base_t *pmm_mmap_init();

// Merges the memory map with SRAT.
void pmm_merge_srat(mmap_base_t *mmap_base);

// Finds the first free frame, allocates it, and returns its address.
ptr_t pmm_frame_alloc();

// Sets a physical frame as free in the bitset.
void pmm_frame_free(ptr_t p);

// Sets a physical frame as used in the bitset.
void pmm_frame_set(ptr_t p);

// Sets a range of physical memory as used in the bitset.
void pmm_frame_range_set(ptr_t start, ptr_t end);

#endif /* _LOADER_PMM_H */
