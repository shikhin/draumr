/* VMM definitions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_VMM_H
#define _LOADER_VMM_H

#include <Types.h>
#include <Macros.h>

#include <MM/Paging.h>

/* SHARED */

#define KERNEL_PAE    1
#define KERNEL_LEGACY 2
#define KERNEL_LONG   3

typedef struct vmm_if vmm_if_t;

struct vmm_if
{
    // Allocates a frame in the virtual address space, and panics if no physical frames are available.
    void (*alloc_frame)(uint64_t addr, uint32_t flags);
    // Map a frame in the virtual address space according to the parameter given.
    void (*map_frame)(uint64_t addr, uint64_t phys, uint32_t flags);
    // Frees a frame in the virtual address space.
    void (*free_frame)(uint64_t addr);
    // Copies from a physical address (source) to a virtual address (destination), when PAGING is DISABLED.
    void (*memcpy_to_virtual)(uint64_t dest, uint64_t source, size_t length);
    // Sets a virtual region to a specified value, when PAGING is DISABLED.
    void (*memset_virtual)(uint64_t dest, uint32_t value, size_t length);
};

// Initializes the Virtual Memory Manager, and enables paging.
void vmm_init(uint8_t type);

void vmm_alloc_frame(uint64_t addr, uint32_t flags);
void vmm_map_frame(uint64_t addr, uint64_t phys, uint32_t flags);
void vmm_free_frame(uint64_t addr);
void memcpy_to_virtual(uint64_t dest, uint64_t source, size_t length);
void memset_virtual(uint64_t dest, uint32_t value, size_t length);

/* LONG MODE VMM */

#define LM_BIT (1 << 8)

/* Structure definitions */

typedef struct long_page_table          long_page_table_t;
typedef struct long_page_dir            long_page_dir_t;
typedef struct long_pdpt		long_pdpt_t;
typedef struct long_pml4		long_pml4_t;

struct long_page_table
{
    uint64_t page[512];
} _packed;

struct long_page_dir
{
    uint64_t page_table[512];
} _packed;

struct long_pdpt
{
    uint64_t page_dir[512];
} _packed;

struct long_pml4
{
    uint64_t pdpt[512];
} _packed;


/* Function definitions */

// Initializes the LONG MODE VMM, and starts up paging.
vmm_if_t* vmm_long_init();


/* PAE VMM */

/* Structure definitions */

typedef struct pae_page_table           pae_page_table_t;
typedef struct pae_page_dir             pae_page_dir_t;
typedef struct pae_pdpt                 pae_pdpt_t;

struct pae_page_table
{
    uint64_t page[512];
} _packed;

struct pae_page_dir
{
    uint64_t page_table[512];
} _packed;

struct pae_pdpt
{
    uint64_t page_dir[4];
} _packed;

/* Function definitions */

// Initializes the PAE VMM, and starts up paging.
vmm_if_t* vmm_pae_init();

/* LEGACY VMM */

/* Structure definitions */

typedef struct leg_page_dir             leg_page_dir_t;
typedef struct leg_page_table           leg_page_table_t;

struct leg_page_dir
{
    uint32_t page_table[1024];
} _packed;

struct leg_page_table
{
    uint32_t page[1024];
} _packed;

/* Function definitons */

// Initializes the Legacy VMM, and starts up paging.
vmm_if_t* vmm_leg_init();

#endif /* _LOADER_VMM_H */
