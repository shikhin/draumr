/* CPU specific functions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_CPU_H_
#define _LOADER_CPU_H_

#include <Types.h>

#define CR0_WP (1 << 16)
#define CR0_PG (1 << 31)

#define cpuid(in, a, b, c, d) \
    __asm__ __volatile__("cpuid" : "=a" (a), "=b" (b), "=c" (c), "=d" (d) : "a" (in));

enum cpu_features
{
    PAE = (1 << 0),
    NX = (1 << 1),
    Long = (1 << 2)
};

reg_t cpu_get_cr0();

void cpu_set_cr0(reg_t r);
void cpu_set_cr3(reg_t r);
void cpu_set_cr4(reg_t r);

void cpu_flush_cr3();

uint32_t cpu_check_cpuid();

uint32_t cpu_features_get();
uint32_t cpu_features_detect();

uint32_t cpu_apic_id_get();

#endif /* _LOADER_CPU_H_ */
