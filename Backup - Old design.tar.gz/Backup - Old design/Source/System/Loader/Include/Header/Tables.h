/* Common (ACPI, MPS and SMBIOS) table definitions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_TABLE_H
#define _LOADER_TABLE_H

#include <Header/Header.h>
#include <Types.h>
#include <Multiboot.h>
#include <Kprintf.h>

#define BDA_EBDA_ADDR		(0x40E)
#define DEFAULT_EBDA_ADDR	(0x9FC00)
#define BIOS_READ_ONLY_MEM	(0xE0000)

#define KIBIBYTE		(0x400)

// Find the tables and returns their address.
void table_find(uint32_t *acpi, uint32_t *mps, uint32_t *smbios, mb_info_t *mb_info);

#endif /* _LOADER_TABLE_H */
