/* SMBIOS relocation (Draumr Header) definitions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_SMBIOS_H
#define _LOADER_SMBIOS_H

#include <Header/Header.h>
#include <Types.h>
#include <Macros.h>

typedef struct smbios_eps smbios_eps_t;

struct smbios_eps
{
    char signature[4];
    uint8_t checksum;
    uint8_t length;
    uint8_t major_version;
    uint8_t minor_version;
    uint16_t max_struct_size;
    uint8_t revision;
    char formatted_are[5];

    char signature_2[5];
    uint8_t checksum_2;
    uint16_t table_length;       
    uint32_t table_addr;	
    uint64_t structure_no;  
    uint8_t bcd_revision;      
} _packed;

/* Relocates the SMBIOS tables, and fills in the neccessary information in the Draumr Header */
void smbios_table_relocate(uint32_t smbios, draumr_hdr_t *draumr_hdr, uint32_t *offset);

/* Finds the length of the SMBIOS tables, for use by 'smbios_table_relocate' to build the neccessary structures */
size_t smbios_table_length(uint32_t smbios);

#endif /* _LOADER_SMBIOS_H */
