/* Draumr Header definitions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_HEADER_H
#define _LOADER_HEADER_H

#define HDR_PHYS		1
#define HDR_VIRT		2

#define RELOCATE_ADDR_32	(0xE0000000)
#define RELOCATE_ADDR_64	(0xFFFFE00000000000)

#define PAE_FLAG		(1 << 0)
#define ACPI_FLAG		(1 << 1)
#define SMBIOS_FLAG		(1 << 2)
#define MPS_FLAG		(1 << 3)

#include <Types.h>
#include <Macros.h>
#include <Multiboot.h>

typedef struct draumr_hdr draumr_hdr_t;
typedef struct tables_if  tables_if_t;

struct draumr_hdr
{
    char signature[8];

    /* Modules.img information */
    uint64_t module_addr;
    uint32_t module_size; 

    /* ACPI, MPS and SMBIOS information */
    uint64_t rsdp;
    uint64_t smbios_entry_point;
    uint64_t mp_floating_point;

    /* Memory map information */
    uint64_t mmap_addr;
    uint32_t mmap_size;
} _packed;

struct tables_if
{
    uint32_t boot_flags;    
    uint32_t acpi_ver;
    uint32_t acpi_addr;
};

// Initializes the Draumr Header, and returns the boot flags to be set.
tables_if_t *draumr_hdr_init(uint32_t init_stage, draumr_hdr_t *draumr_hdr, mb_info_t* mb_info);

#endif /* _LOADER_HEADER_H */
