/* MPS relocation (Draumr Header) definitions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_MPS_H
#define _LOADER_MPS_H

#include <Header/Header.h>
#include <Types.h>
#include <Macros.h>

typedef struct mpfs mpfs_t;
typedef struct mpct mpct_t;

struct mpfs
{
    char signature[4];
    uint32_t mpct_address; 
    uint8_t length;
    uint8_t specification;
    uint8_t checksum;
    uint8_t feature_info;
    uint32_t feature_info_2;
} _packed;

struct mpct
{
    char signature[4];
    uint16_t base_length;
    uint8_t revision;
    uint8_t checksum;
    char oemid[8];
    char product_id[12];
    uint32_t oem_table_pointer;
    uint16_t oem_table_size;
    uint16_t entry_count;
    uint32_t local_apic_addr;
    uint16_t extended_length;
    uint8_t extended_checksum;
    uint8_t reserved;
    uint8_t first_type;
} _packed;

/* Relocates the MPS tables, and fills in the neccessary information in the Draumr Header */
void mps_table_relocate(uint32_t mps, draumr_hdr_t *draumr_hdr, uint32_t *offset);

/* Returns the total length of the MPS tables, which is used by 'mps_table_relocate' to create neccessary tables
 * If vers is a non-zero number, the MPCT should be copied. Else not.  */
size_t mps_table_length(uint32_t mps, uint32_t *vers);

#endif /* _LOADER_MPS_H */
