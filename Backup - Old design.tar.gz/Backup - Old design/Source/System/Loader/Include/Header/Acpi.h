/* ACPI relocation (Draumr Header) definitions.
 *
 * Copyright (c) 2011 Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LOADER_ACPI_H
#define _LOADER_ACPI_H

#include <Header/Header.h>
#include <Types.h>
#include <Macros.h>

typedef struct rsdp		rsdp_t;
typedef struct rsdp2		rsdp2_t;
typedef struct sdt_header	sdt_header_t;
typedef struct rsdt		rsdt_t;
typedef struct xsdt		xsdt_t;

struct rsdp
{
    char signature[8];
    uint8_t checksum;
    char oemid[6];
    uint8_t revision;
    uint32_t rsdt_address;
} _packed;

struct rsdp2
{
    char signature[8];
    uint8_t checksum;
    char oemid[6];
    uint8_t revision;
    uint32_t rsdt_address;

    uint32_t length;
    uint64_t xsdt_address;
    uint8_t extended_checksum;
    uint8_t reserved[3];
} _packed;

struct sdt_header 
{
    char signature[4];
    uint32_t length;
    uint8_t revision;
    uint8_t checksum;
    char oemid[6];
    char oem_table_id[8];
    uint32_t oem_revision;
    uint32_t creator_id;
    uint32_t creator_revision;
} _packed;

struct rsdt
{
    sdt_header_t header;
    uint32_t first_sdt;
} _packed;

struct xsdt
{
    sdt_header_t header;
    uint64_t first_sdt;
} _packed;

/* Relocates the ACPI tables, and fills in the neccessary information in the Draumr Header */
void acpi_table_relocate(uint32_t acpi, draumr_hdr_t *draumr_hdr, uint32_t *offset);

/* Returns the total length of the ACPI tables, which is used by 'acpi_table_relocate' to create neccessary tables
 * If vers contains a non-zero value, the XSDT must be used. Else the RSDT */
size_t acpi_table_length(uint32_t acpi, uint32_t *vers);

#endif /* _LOADER_ACPI_H */
