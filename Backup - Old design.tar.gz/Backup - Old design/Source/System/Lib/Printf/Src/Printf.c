/* Printf implementation.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Printf.h>

enum printf_state
{
    NORMAL,
    FORMAT
};

static const char num_digits[] = "0123456789abcdef";

static void printf_puts(printf_helper_t* helper, void* data, char* s)
{
    if (s == NULL)
        s = "<NULL>";

    while (*s)
        helper(data, *s++);
}

static void printf_putn(printf_helper_t* helper, void* data, uint32_t n, int base, int negative)
{
    int i = 0;
    char b[16];

    if (n == 0)
    {
        helper(data, '0');
        return;
    }

    while (n != 0)
    {
        b[i++] = num_digits[n % base];
        n /= base;
    }

    if (negative)
        helper(data, '-');

    while (i > 0)
        helper(data, b[--i]);
}

void do_printf(printf_helper_t* helper, void* data, const char* fmt, va_list args)
{
    char c;
    enum printf_state state = NORMAL;

    for (; (c = *fmt) != 0; ++fmt)
    {
        switch (state)
        {
            case NORMAL :
                if (c == '%')
                    state = FORMAT;
                else
                    helper(data, c);

                break;

            case FORMAT :
                switch (c)
                {
                    case 's' :
                    {
                        char* s = va_arg(args, char*);
                        printf_puts(helper, data, s);
                        state = NORMAL;
                        break;
                    }

                    case 'c' :
                    {
                        char ch = (char)va_arg(args, uint32_t);
                        helper(data, ch);
                        state = NORMAL;
                        break;
                    }

                    case 'd' :
                    {
                        int n = va_arg(args, int);
                        int negative = 0;

                        if (n < 0)
                        {
                            n = -n;
                            negative = 1;
                        }

                        printf_putn(helper, data, (uint32_t)n, 10, negative);
                        state = NORMAL;
                        break;
                    }

                    case 'u' :
                    {
                        uint32_t n = va_arg(args, uint32_t);
                        printf_putn(helper, data, n, 10, 0);
                        state = NORMAL;
                        break;
                    }

                    case 'x' :
                    case 'p' :
                    {
                        uint32_t n = va_arg(args, uint32_t);
                        printf_putn(helper, data, n, 16, 0);
                        state = NORMAL;
                        break;
                    }

                    case '%' :
                        helper(data, '%');
                        state = NORMAL;
                        break;

                    default :
                        state = NORMAL;
                        break;
                }

                break;
        }
    }
}
