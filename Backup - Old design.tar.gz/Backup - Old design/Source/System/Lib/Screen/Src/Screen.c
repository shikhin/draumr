/* Screen manipulating functions.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Types.h>
#include <IO.h>

#include <Screen.h>

static uint16_t* scr_mem;
uint16_t scr_attr = (7 << 8);
static uint16_t scr_x = 0, scr_y = 0;

static inline void screen_cursor_update()
{
    register uint16_t c_loc = scr_y * 80 + scr_x;

    outb(0x3d4, 14);
    outb(0x3d5, c_loc >> 8);
    outb(0x3d4, 15);
    outb(0x3d5, c_loc & 0xff);
}

static inline void screen_cursor_get_pos(uint16_t* x, uint16_t* y)
{
    uint16_t data = 0;

    outb(0x3d4, 14);
    data |= (inb(0x3d5) << 8);
    outb(0x3d4, 15);
    data |= inb(0x3d5);

    *x = data % 80;
    *y = data / 80;
}

static inline void screen_scroll_up()
{
    /* Scroll screen contents up. */
    for (size_t i = 0; i < (80 * 24); ++i)
        scr_mem[i] = scr_mem[i + 80];

    /* Blank the last line. */
    for (size_t i = 80 * 24; i < 80 * 25; ++i)
        scr_mem[i] = ' ' | scr_attr;

    /* Update cursor position. */
    scr_y--;
}

void screen_putc(char c)
{
    switch (c)
    {
        /* Carriage return */
        case '\r' :
            scr_x = 0;
            break;

        /* New line */
        case '\n' :
            scr_x = 0;
            scr_y++;
            break;

        /* Back space */
        case '\b' :
            if (scr_x)
                scr_x--;
            else if ((!scr_x) && scr_y)
            {
                scr_x = 79;
                scr_y--;
            }
            break;

        /* Tab */
        case '\t' :
            scr_x = (scr_x + 8) & ~(8 - 1);
            break;

        default :
        {
            uint16_t* p = scr_mem + (scr_y * 80) + scr_x;
            *p = c | scr_attr;
            scr_x++;
            break;
        }
    }

    /* End of the line reached? */
    if (scr_x == 80)
    {
        scr_x = 0;
        scr_y++;
    }

    /* Do we need to scroll up the screen? */
    if (scr_y >= 25)
        screen_scroll_up();

    /* Update cursor position on the screen. */
    screen_cursor_update();
}

void screen_init(ptr_t scr_ptr, int clear)
{
    scr_mem = (uint16_t*)scr_ptr;
    if (clear)
    {
        for (size_t i = 0; i < 80 * 25; ++i)
            scr_mem[i] = ' ' | scr_attr;

        screen_cursor_update();
    }
    else
        screen_cursor_get_pos(&scr_x, &scr_y);
}
