/* Generic bitmap implementation.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <Bitmap.h>

/* Find the first free bit in the bitmap, and returns it. 1 if no free frame found */
int bitmap_first_free(bitmap_t* b, size_t* bit)
{
    for (size_t i = b->first_free_idx; i < (b->size / 32); i++)
    {
        if (b->buffer[i] == 0xffffffff)
            continue;

        else if (b->buffer[i] == 0x00000000)
        {
            b->first_free_idx = i;
            *bit = (i * 32);
            return 1;
        }

        else
        {
            __asm__ __volatile__("bsf %1, %0" : "=r" (*bit) : "r" (~(b->buffer[i])));
            b->first_free_idx = i;
            *bit = (i * 32) + *bit;
            return 1;
        }
    }

    for (size_t i = 0; i < b->first_free_idx; i++)
    {
        if (b->buffer[i] == 0xffffffff)
            continue;

        else if (b->buffer[i] == 0x00000000)
        {
            b->first_free_idx = i;
            *bit = (i * 32);
            return 1;
        }

        else
        {
            __asm__ __volatile__("bsf %1, %0" : "=r" (*bit) : "r" (~(b->buffer[i])));
            b->first_free_idx = i;
            *bit = (i * 32) + *bit;
            return 1;
        }
    }

    return 0;
}

/* Sets nth'bit' in the bitmap */
void bitmap_set(bitmap_t* b, size_t bit)
{
    if (bit >= b->size)
        return;

    b->buffer[INDEX_FROM_BIT(bit)] |= (1 << (OFFSET_FROM_BIT(bit)));
}

/* Clears nth'bit' in the bitmap */
void bitmap_clear(bitmap_t* b, size_t bit)
{
    if (bit >= b->size)
        return;

    b->buffer[INDEX_FROM_BIT(bit)] &= ~(1 << (OFFSET_FROM_BIT(bit)));

    if (INDEX_FROM_BIT(bit) < b->first_free_idx)
        b->first_free_idx = INDEX_FROM_BIT(bit);
}

/* Checks if nth'bit' in the bitmap is set or not */
int bitmap_is_set(bitmap_t* b, size_t bit)
{
    if (bit >= b->size)
        return 0;

    return (b->buffer[INDEX_FROM_BIT(bit)] & (1 << (OFFSET_FROM_BIT(bit))));
}

/* Initializes a bitmap */
int bitmap_init_buf(bitmap_t* b, size_t size, uint32_t* buf)
{
    b->size = size;
    b->buffer = buf;
    b->first_free_idx = 0;

    return 0;
}
