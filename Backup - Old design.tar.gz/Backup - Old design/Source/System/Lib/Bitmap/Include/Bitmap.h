/* Generic bitmap implementation.
 *
 * Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _LIB_BITMAP_BITMAP_H_
#define _LIB_BITMAP_BITMAP_H_

#include <Types.h>

#define INDEX_FROM_BIT(a)  ((a) / 32)
#define OFFSET_FROM_BIT(a) ((a) % 32)

typedef struct bitmap bitmap_t;

struct bitmap
{
    size_t size;
    size_t first_free_idx;
    uint32_t* buffer;
};

/* Sets nth'bit' in the bitmap */
void bitmap_set(bitmap_t* b, size_t bit);

/* Clears nth'bit' in the bitmap */
void bitmap_clear(bitmap_t* b, size_t bit);

/* Checks if nth'bit' in the bitmap is set or not */
int bitmap_is_set(bitmap_t* b, size_t bit);

/* Find the first free bit in the bitmap. Returns true if found, false otherwise. */
int bitmap_first_free(bitmap_t* b, size_t* bit);

/* Initializes a bitmap */
int bitmap_init_buf(bitmap_t* b, size_t size, uint32_t* buf);

#endif /* _LIB_BITMAP_BITMAP_H_ */
