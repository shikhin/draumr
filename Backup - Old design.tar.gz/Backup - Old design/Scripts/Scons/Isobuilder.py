# Draumr build system
#
# Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

import os
import shutil
import tempfile
import glob

from SCons.Builder import Builder
from SCons.Action import Action

def _path(p) :
    return os.path.sep.join(p)

def _grub_config(loader) :
    s = ""
    s += "set timeout=10\n"
    s += "set default=0\n"
    s += "menuentry 'Draumr' {\n"
    s += "legacy_kernel '/System/Loader' '/System/Loader'\n"
    s += "legacy_initrd '/System/Kernel' '/System/Kernel'\n"
    s += "legacy_initrd '/System/KernelLong' '/System/KernelLong'\n"
    s += "}"
    return s

def _pxelinux_config_etherboot() :
    s = ""
    s += "default Draumr\n"
    s += "label Draumr\n"
    s += "kernel mboot.c32\n"
    s += "append Loader --- Kernel --- KernelLong\n"
    return s

def _iso_builder(target, source, env) :
    # Create a temporary directory to build the ISO image structure.
    d = tempfile.mkdtemp()

    # Copy the kernel to the image.
    s = _path([d, "System"])
    os.mkdir(s)
    loader = str(env["LOADER"][0])
    kernel = str(env["KERNEL"][0])
    kernel_long = str(env["KERNEL_64"][0])
    shutil.copy(loader, s)
    shutil.copy(kernel, s)
    shutil.copy(kernel_long, s)

    # Create the boot directory.
    p = _path([d, "boot", "grub"])
    os.makedirs(p)

    f = open(_path([d, "boot", "grub", "grub.cfg"]), "w")
    f.write(_grub_config("/System/Loader"))
    f.close()

    eltorito = _path([d, "boot", "grub", "eltorito.img"])
    core = _path([d, "boot", "grub", "core.img"])

    os.system("grub-mkimage -o %s multiboot legacycfg biosdisk iso9660 configfile -O i386-pc" % (core))
    os.system("cat /usr/lib/grub/i386-pc/cdboot.img %s > %s" % (core, eltorito))

    os.system("mkisofs -R -l -b %s -boot-load-size 4 -boot-info-table -no-emul-boot -o %s %s" % ("boot/grub/eltorito.img", target[0], d))

    # Clean up our mess. :)
    shutil.rmtree(d)
    return 0

def _ethernet_builder(target, source, env) :
    p = _path(["/tftpboot", "pxelinux.cfg"])

    f = open(_path([p, "default"]), "w")
    f.write(_pxelinux_config_etherboot())
    f.close()

    loader = str(env["LOADER"][0])
    kernel = str(env["KERNEL"][0])
    kernel_long = str(env["KERNEL_64"][0])
    shutil.copy(loader, "/tftpboot")
    shutil.copy(kernel, "/tftpboot")
    shutil.copy(kernel_long, "/tftpboot")
    shutil.copy("Utilities/pxelinux.0", "/tftpboot")
    shutil.copy("Utilities/mboot.c32", "/tftpboot")

ISOBuilder = Builder(action = Action(_iso_builder, None))
NetbootBuilder = Builder(action = Action(_ethernet_builder, None))
