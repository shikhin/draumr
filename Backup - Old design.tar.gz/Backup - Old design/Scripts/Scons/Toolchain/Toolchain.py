# Draumr build system
#
# Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

import os

from Binutils import Binutils
from Gcc import GCC

class Toolchain :
    targets = {"i686" : "i686-pc-draumr", "amd64" : "x86_64-pc-draumr"}

    def __init__(self, config) :
        self.arch = config.get_arch()
        self.ccpath = "crosscompiler_" + self.arch

        self.components = [
            Binutils(self.ccpath, self.targets[self.arch]),
            GCC(self.ccpath, self.targets[self.arch])
        ]

    def check(self) :
        os.chdir("Toolchain")

        try :
            for c in self.components :
                if not c.check() :
                    return False

            return True
        finally :
            os.chdir("..")

    def create(self, target, source, env) :
        # Save the CWD and go into the toolchain directory.
        oldcwd = os.getcwd()
        os.chdir("Toolchain")

        # Create a directory for the crosscompiler.
        if not os.path.isdir(self.ccpath) :
            os.mkdir(self.ccpath)

        # Download the components of the toolchain.
        for c in self.components :
            c.download()

        # Build the toolchain components.
        for c in self.components :
            c.build()

        # Go back to the original directory.
        os.chdir(oldcwd)

        return 0

    def get_path(self) :
        return os.path.sep.join(["Toolchain", "crosscompiler_" + self.arch])
