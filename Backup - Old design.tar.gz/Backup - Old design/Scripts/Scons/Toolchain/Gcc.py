# Draumr build system
#
# Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

import os
import shutil

from Component import Component

class GCC(Component) :
    def __init__(self, ccpath, target) :
        Component.__init__(
            self,
            ccpath,
            target,
            "http://ftp.gnu.org/gnu/gcc/gcc-4.5.2/gcc-core-4.5.2.tar.bz2",
            "gcc-core-4.5.2.tar.bz2",
            "aa9e36bec080452372bfba793428ee82",
            ["gcc-4.5.2.patch"],
            ["bin/%s-gcc" % target]
        )

    def build(self) :
        self.extract()
        self.patch()

        os.mkdir("gcc-build")
        os.chdir("gcc-build")

        # Build configure command.
        cfg = "../gcc-4.5.2/configure --target=%s --prefix=%s/../%s --disable-nls --enable-shared --enable-languages=c" \
            % (self.target, os.getcwd(), self.ccpath)

        # Maybe mpfr, gmp and mpc libraries are not at the standard place, so we accept external
        # paths through MPFR_PATH, GMP_PATH and MPC_PATH environment variables.
        mpfr = os.getenv("MPFR_PATH")
        gmp = os.getenv("GMP_PATH")
        mpc = os.getenv("MPC_PATH")

        if mpfr :
            cfg += " --with-mpfr=%s" % mpfr
        if gmp :
            cfg += " --with-gmp=%s" % gmp
        if mpc :
            cfg += " --with-mpc=%s" % mpc

        self.execute(cfg)
        self.execute("make all-gcc")
        self.execute("make all-target-libgcc")
        self.execute("make install-gcc")
        self.execute("make install-target-libgcc")
        os.chdir("..")
        shutil.rmtree("gcc-build")
        shutil.rmtree("gcc-4.5.2")
