# Draumr build system
#
# Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

import os
import shutil

from Component import Component

class Binutils(Component) :
    def __init__(self, ccpath, target) :
        Component.__init__(
            self,
            ccpath,
            target,
            "http://ftp.gnu.org/gnu/binutils/binutils-2.21.tar.bz2",
            "binutils-2.21.tar.bz2",
            "c84c5acc9d266f1a7044b51c85a823f5",
            ["binutils-2.21.patch"],
            ["bin/%s-ld" % target]
        )

    def build(self) :
        self.extract()
        self.patch()

        os.mkdir("binutils-build")
        os.chdir("binutils-build")
        self.execute("../binutils-2.21/configure --target=%s --prefix=%s/../%s --disable-nls --disable-werror" \
            % (self.target, os.getcwd(), self.ccpath))
        self.execute("make")
        self.execute("make install")
        os.chdir("..")
        shutil.rmtree("binutils-build")
        shutil.rmtree("binutils-2.21")
