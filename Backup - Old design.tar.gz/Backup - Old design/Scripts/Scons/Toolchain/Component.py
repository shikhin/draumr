# Draumr build system
#
# Copyright (c) 2011 Zoltan Kovacs, Shikhin Sethi
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

import os
import urllib
import hashlib

from sys import stdout

class Component :
    def __init__(self, ccpath, target, source, filename, md5sum, patches, files) :
        self.ccpath = ccpath
        self.target = target
        self.source = source
        self.filename = filename
        self.md5sum = md5sum
        self.patches = patches
        self.files = files

    def check(self) :
        for f in self.files :
            if not os.path.isfile(os.path.sep.join([self.ccpath, f])) :
                return False

        return True

    def download(self) :
        if os.path.isfile(self.filename) :
            d = self._count_md5()
            if d == self.md5sum :
                return
            else :
                os.remove(self.filename)

        self._download()
        d = self._count_md5()

        return d == self.md5sum

    def extract(self) :
        self.execute("tar xvf %s" % self.filename)

    def patch(self) :
        for p in self.patches :
            self.execute("patch -p0 < %s" % p)

    def execute(self, cmd) :
        os.system(cmd)

    def _download(self) :
        stdout.write("Downloading %s ...     " % self.filename)
        self._download_status(0)

        s = urllib.urlopen(self.source)
        f = open(self.filename, "w")

        done = 0
        size = int(s.headers.getheader("Content-Length"))

        data = s.read(512)
        while data :
            done += len(data)
            self._download_status(done * 100 / size)
            f.write(data)
            data = s.read(512)

        print
        f.close()

    def _download_status(self, s) :
        stdout.write("\b\b\b\b%3d%%" % s)
        stdout.flush()

    def _count_md5(self) :
        f = open(self.filename, "r")
        h = hashlib.md5()
        h.update(f.read())
        f.close()
        return h.hexdigest()
